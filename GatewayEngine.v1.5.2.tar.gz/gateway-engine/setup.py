""" Installer for Gateway Engine. """
# pylint: disable=W0312
import os, sys, fnmatch
from setuptools import setup, find_packages, Command

DOCS_URL = 'docs.exosite.com/exositeready/gwe'

def read(fname):
    """ Primarily used to open README file. """
    return open(os.path.join(os.path.dirname(__file__), fname)).read()

print("setup.py: packages = {!r}".format(find_packages()))

try:
    README = read('README.md')
except:
    README = DOCS_URL

from GatewayEngine import __version__
print("GatewayEngine version: {}".format(__version__))

class Install_Dependencies(Command):
    """ Run my command.
    """
    description = 'Install the gateway dependencies from deps/ directory.'

    user_options = [
            # ('opt-long=', 'o', 'a command line option, o is the short-option'),
        ]

    def initialize_options(self):
        self.deps_dir = "deps"
        print("Installing dependencies...")

    def finalize_options(self):
        pass

    def run(self):
        from GatewayEngine.installer import Installer
        from GatewayEngine.utils import engine_conf
        import logging

        logging.basicConfig()

        def find_dependency(package):
            """
                Locates device-client for installation. Returns the first result.
            """
            print("Locating '{}' in {}".format(package, self.deps_dir))
            result = []
            for root, dirs, files in os.walk(self.deps_dir):
                for name in files:
                    if fnmatch.fnmatch(name, package):
                        dependency = os.path.join(root, name)
                        result.append(dependency)
                        sys.stderr.write("Found dependency: {}\n".format(dependency))
            if len(result) < 1:
                sys.stderr.write("Unable to locate dependency for install. Exiting.\n")
                sys.exit(-1)
            return result[0] # return the top result, throw away all others

        for package in ["device-client.v*.tar.gz", "acp.v*.tar.gz"]:
            path = find_dependency(package)
            i = Installer(path, engine_conf())
            i.install()
            for line in i.stdout.split('\n'):
                print(line)

        print("Installation successful" if 0 == i.code \
                else "There was an issue with the installation. Exit code: {}".format(i.code))

setup(
    name = "GatewayEngine",
    version = __version__,
    author = "Andy Lee, Will Charlton",
    author_email = "andylee@exosite.com, willcharlton@exosite.com",
    description = ("""================================================================================
================================================================================
================================================================================

                               Gateway Engine

Gateway Engine is an Exosite product that manages applications and
communications on internet gateways. It is a generalized gateway application
framework that provides API libraries, OTAU, telemetric, logging, process
management and add-ons.

Gateway Engine is the product that installs and modifies software over-the-air
in a secure and scalable manner.

For more information, please visit {0}
================================================================================
================================================================================""".format(
    DOCS_URL)),
    license = "Apache 2.0",
    keywords = "andy will exosite iot exo gateway engine gatewayengine atomicconfigparser",
    url = "https://i.exosite.com/git/gateway-engine/gateway-engine",
    packages=find_packages(),
    cmdclass = {
        'gdc': Install_Dependencies,
    },
    entry_points={
        'console_scripts': [
            'gwe = GatewayEngine.cli:main',
        ],
    },
    package_data={'GatewayEngine': ['Engine.config', 'Gateway.cfg']},
    # install_requires = [ 'exo', ],
    # dependency_links = [
    #     'git+ssh://git@github.com/exosite/device-client.git@docs#egg=device-client',
    # ],
    long_description=README,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Programming Language :: Python :: 2.7",
        "Operating System :: POSIX :: Linux",
        "Topic :: System :: Operating System Kernels :: Linux",
        "Topic :: Software Development :: Embedded Systems",
        "License :: Other/Proprietary License",
    ],
)
