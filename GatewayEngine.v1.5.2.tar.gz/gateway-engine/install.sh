#!/bin/sh

# run entire script in a sub-shell so all output can be tee'd
# to the gwe_install.log file
(
set -x

INIT_PATH=init
APPS_PATH=apps_to_install

echo "Installing GWE Version: $(python -c 'import GatewayEngine ; print(GatewayEngine.__version__)')"

if [ ! -e THIS_IS_AN_OTAU.txt ] ; then
    # run the init/init.sh script
    cd init
    if [ -e init.sh ] ; then
        ./init.sh
        # Check exit code
        if [ $? -ne 0 ] ; then
            echo "'init.sh' execution failed. Exiting..."
            exit -1
        fi
        cd ..
    else
        echo "'init.sh' not found. Exiting..."
        exit -1
    fi
    # Now run any commands that might be specified in the pre_install_commands
    # function of gwe.build files from Custom Gateway Application's build with packager.sh
    [ -e $INIT_PATH/pre_install_commands.sh ] && sh $INIT_PATH/pre_install_commands.sh
fi

# create supervisor directories
mkdir -p /etc/supervisor/conf.d

echo "Copying supervisord.conf"
[ ! -e /etc/supervisord.conf ] && cp ${INIT_PATH}/supervisord.conf /etc/

echo "Copying GatewayEngine's supervisord conf file."
cp ${INIT_PATH}/gwe.conf /etc/supervisor/conf.d/

# install setuptools
if [ -e ez_setup.py ] ; then
    python ez_setup.py
    # Check exit code
    if [ $? -ne 0 ] ; then
        EASY_SETUP_STAT="'ez_setup.py' execution failed. Exiting..."
    else
        EASY_SETUP_STAT="'ez_setup.py' installation successful."
    fi
else
    EASY_SETUP_STAT="'ez_setup.py' not found, setuptools can not be installed. Exiting..."
fi

# install pip
PIP=pip-9.0.1
PIP_TARBALL_NAME="${PIP}.tar.gz"
if [ -e ${PIP_TARBALL_NAME} ] ; then
    python -c "import tarfile ; tarfile.open('${PIP_TARBALL_NAME}').extractall()"
    cd ${PIP}
    # Check exit code
    if [ $? -ne 0 ] ; then
        echo "Unable to 'cd' to '${PIP}' directory. Unable to install pip.."
    else
        python setup.py install
        # Check exit code
        if [ $? -ne 0 ] ; then
            echo "${PIP} 'setup.py' execution failed. Exiting..."
        fi
        cd ..
    fi
else
    echo "'${PIP_TARBALL_NAME}' not found. Unable to (re-)install ${PIP}."
fi
# declare path to gwe installer locally to
# this install package
INSTALLER=GatewayEngine/installer.py

# make sure device-client is installed first, but before
# doing that, there could potentially be an old version of device-client
# that spoiled that python namespace of `exo` - remove this
EASY_INSTALL_PTH=$(python << EOF
import os,sys
try:
    import exo
except ImportError:
    sys.stderr.write('No previous version of device-client detected.\n')
    sys.exit(0)
p = os.path.dirname(exo.__file__)
fname = 'easy-install.pth'
easyInstallDotPth = os.path.join(p, fname)
FOUND_IT = False
while not FOUND_IT:
    if os.path.exists(easyInstallDotPth):
        FOUND_IT = True
    else:
        easyInstallDotPth = os.path.join(
                os.path.split(
                    os.path.split(easyInstallDotPth)[0]
                )[0],
                fname
        )
print(easyInstallDotPth)
EOF
)

# now remove the old version from the easy-install.pth
if [ "" != "${EASY_INSTALL_PTH}" ] ; then
    if grep -q device_client "${EASY_INSTALL_PTH}"
    then
        cp "${EASY_INSTALL_PTH}" "${EASY_INSTALL_PTH}.orig"
        grep -v device_client "${EASY_INSTALL_PTH}" > "${EASY_INSTALL_PTH}.mod"
        cp "${EASY_INSTALL_PTH}.mod" "${EASY_INSTALL_PTH}"
    else
        echo "No end-of-life'd versions of device_client detected."
    fi
fi

# install device-client
python setup.py gdc

# DEVICE_CLIENT_PATH=$(find ${PWD} -name "device-client.v*.tar.gz" -print)
# ${INSTALLER} ${DEVICE_CLIENT_PATH}

if [ ! -e THIS_IS_AN_OTAU.txt ] ; then
    # install apps first as they might be dependencies for GWE
    APPLICATIONS=$(find $APPS_PATH -maxdepth 1 ! -path $APPS_PATH ! -name "*.sh")
    echo "Found apps: $APPLICATIONS" | tee gwe_apps_install.log

    # invariably, requests and device-client will install twice. deal with it - they are both stateless
    echo "Executing '$INSTALLER' on '$APPLICATIONS' packages." | tee gwe_apps_install.log
    for app in $APPLICATIONS; do
        INSTALL_APP=$(basename $app)
        $INSTALLER $app 2>&1 | tee ${INSTALL_APP}_app_install.log
        echo $? > ${INSTALL_APP}_exit.code
    done
else
    python otau.py
fi

# Install GWE
python setup.py install --record=installed.files
GWE_INSTALL_CODE=$?

# now we need to find out whether this is a new install
# or if this is an OTAU for GWE itself
SPRVR_PID=`pidof supervisord`
echo "Checking for PID of supervisord: $SPRVR_PID"
# if this is an OTAU update of GWE, then we can't rely on GWE to restart
# because it's default behavior is to STOP the new app, then RELOAD
# supervisor's conf files, then START the app again
# if we let GWE do this, it wouldn't ever start up again
# therefore, restart it manually here.
# check to see if supervisord is already running, if so, stop it
# and restart everything manually

[ "" != "$(which supervisorctl)" ] && [ -e THIS_IS_AN_OTAU.txt ] && \
    supervisorctl reload

# It is tempting to start supervisord at this point, but don't.
# In order to complete a full install from a fresh OS, the gateway
# must be rebooted. There is an init.d script that will take care
# of starting supervisord.

# Now run any commands that might be specified in the post_install_commands
# function of gwe.build
[ -e $INIT_PATH/post_install_commands.sh ] && sh $INIT_PATH/post_install_commands.sh

set +x

echo "********************* Installation Summary : ******************************"
echo "Username: "$(whoami)
if [ $GWE_INSTALL_CODE -eq 0 ]
 then
    echo "GWE Installed Successfully"
else
    echo "GWE Installation Failed : Error Code $GWE_INSTALL_CODE"
fi

echo $EASY_SETUP_STAT

gwe -v
# Check exit code
if [ $? -ne 0 ] ; then
    echo "Gateway Engine appears to have installed, but the command-line has a non-zero exit code."
fi

for code in $(ls *_exit.code) ; do
    app="${code%_exit.code}"
    if [ "$(cat $code)" != "0" ] ; then
        echo "Installation for $app failed!"
        awk '{print $0}' $app_app_install.log
    else
        echo "Installation for $app passed."
    fi
done

echo "Running self test..."
python -m unittest test.self_test

echo "********************* Installation Complete ******************************"

exit 0
) 2>&1 | tee gwe_install_"$(date +%Y-%m-%d_%T-%Z)".log

