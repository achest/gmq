"""***************************************************************************************
* Project           : Gateway Engine
*
* Module name       : test_gateway_engine.py
*
* Author            : Will Charlton
*
* Date created      :
*
* Purpose           : Testing basic GatewayEngine functionality.
*
* Revision History  :
*
* Date              Author          Description
*------------      -----------     -------------------------------------------------------
* Aug 2, 2016      Prakash S      Changed tests to use ENV variables instead of files.

|**************************************************************************************"""

"""
    Test execution instructions:

    $ pwd
        .../gateway-engine/
    $ ls
        ... etc ...
        /test
    $ export VENDOR="vendor_name"
    $ export VENDOR_TOKEN="40_char_secret_token"
    $ python -m unittest discover test

"""


# pylint: disable=R0201,W0312

import unittest, glob, tempfile,shutil
from GatewayEngine import tarball
from GatewayEngine import installer
from GatewayEngine.GatewayEngine import Gateway,\
                                        Engine, \
                                        EngineCfgSects, \
                                        EngineCfgOpts, \
                                        GatewayCfgSects, \
                                        GatewayCfgOpts
from exo.device import DeviceCfgSect, DeviceCfgOpt
import os, platform
import logging
import json
from GatewayEngine.__version__ import __version__ as GWE_VERSION
from GatewayEngine.constants import user_agent_prefix
import sys, ConfigParser
from GatewayEngine.tarball import Tarball
from GatewayEngine import cli

logging.basicConfig()

# uncomment to view http/requests debug output
# import httplib
# httplib.HTTPConnection.debuglevel = 1
JENKINS_INSTALL_DIR = './tmp'
os.environ['JENKINS_INSTALL_DIR'] = JENKINS_INSTALL_DIR

USER_AGENT = 'Test_GatewayEngine'
MODEL = 'aptivator_v1'
UUID = 'ap:ti:va:to:rt:st'
if 'Darwin' == platform.system():
    IFACE = 'en0'
elif os.path.exists('/.dockerenv'):
    IFACE = 'eth1'
    for iface in ['eth0', 'eth1', 'eth2']:
        if os.system('ip addr show {}'.format(iface)) == 0:
            IFACE = iface
            print("Using iface: {}".format(IFACE))
else:
    IFACE = 'eth0'
TEST_CFG_FILE = 'test.cfg'

# These are set, first, in the Jenkins Job Configuration for APtivator,
# then by the test_aptivator.sh jenkins script. This keeps the vendor
# and vendor token info out of the git repo.
print("PWD: {0}".format(os.path.abspath(os.path.curdir)))
VENDOR = os.environ['VENDOR']
VENDOR_TOKEN = os.environ['VENDOR_TOKEN']
print("VENDOR = {0}".format(VENDOR))
print("VENDOR TOKEN = {0}".format(VENDOR_TOKEN))


class Test_Gateway(unittest.TestCase):
    """ Run some tests on Gateway object. """
    @classmethod
    def setUpClass(cls):
        # file should be ConfigParser compatible.
        open(TEST_CFG_FILE, 'wb').write("""[device]
cik = ''
model = {0}
vendor = {1}
uuid = {2}
iface = {3}

[dataports]
usage_report = usage_report
engine_report = engine_report
engine_fetch = engine_fetch
device_info = device_info
fetch_status = fetch_status
update_interval = update_interval

""".format(MODEL, VENDOR, UUID, IFACE))
        print("Using config file: {}".format(
            open(TEST_CFG_FILE, 'r').read()))

        # it is probably wrong, philosophically, to used code you intend to
        # test in order to set up for that test, but I'm doing it anyways
        # D = Device(USER_AGENT, TEST_CFG_FILE)
        # regen_success = D._http_regen(VENDOR_TOKEN)
        # print("What happened here: {}".format(str(regen_success)))
        # assert regen_success.code == 205

    @classmethod
    def tearDownClass(cls):
        """ Remove test file. """
        os.remove(TEST_CFG_FILE)

    def setUp(self):
        """ Setup for test. """
        self.test_tarball = 'test_app.v1.tar.gz'
        self.engine_cfg = 'engine_test.cfg'
        self.gw_cfg = 'gw_test.cfg'

        # create engine config file
        open(self.engine_cfg, 'wb').write("""[{0}]
counter = 0
dummy = 5

[{1}]
{2} = {3}
{4} = {5}
""".format(EngineCfgSects.Apps,
            EngineCfgSects.Device,
            EngineCfgOpts.UpdateInterval, 43200,
            EngineCfgOpts.UserAgent, USER_AGENT))

        # create Gateway cfg file
        open(self.gw_cfg, 'wb').write("""[{0}]
{1} = {2}
{3} = {4}
{5} = {6}
{7} = {8}
{9} = {10}

[{11}]
{12} = {13}
{14} = {15}
{16} = {17}
{18} = {19}
{20} = {21}
{22} = {23}
""".format(DeviceCfgSect.Device,
            DeviceCfgOpt.Cik, '',
            DeviceCfgOpt.Model, MODEL,
            DeviceCfgOpt.Vendor, VENDOR,
            DeviceCfgOpt.Uuid, UUID,
            'iface', IFACE,
            GatewayCfgSects.Dataports,
            GatewayCfgOpts.UsageReport, GatewayCfgOpts.UsageReport,
            GatewayCfgOpts.UpdateInterval, GatewayCfgOpts.UpdateInterval,
            GatewayCfgOpts.EngineReport, GatewayCfgOpts.EngineReport,
            GatewayCfgOpts.EngineFetch, GatewayCfgOpts.EngineFetch,
            GatewayCfgOpts.DeviceInfo, GatewayCfgOpts.DeviceInfo,
            GatewayCfgOpts.FetchStatus, GatewayCfgOpts.FetchStatus))
        print("Using config file: {}".format(
            open(self.gw_cfg, 'r').read()))


    def tearDown(self):
        """ Remove test file. """
        os.remove(self.engine_cfg)
        os.remove(self.gw_cfg)

    def test_1_activate(self):
        """ Test the exo_report functionality of Gateway Device. """

        print("################## Starting TEST 1 ########################")
        # set up Gateway for test
        GW = Gateway(self.gw_cfg, logging.DEBUG)
        print(GW)

        # set up engine for test
        E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
        print(E)

        # regen aptivator
        print(GW._http_regen(VENDOR_TOKEN))
        GW.ACTIVATION_INTERVAL = 2 # 2 seconds
        GW._set_uuid(UUID)
        GW.activate()
        self.assertEquals(GW.activated(), True)
        print("################## Ending TEST 1 ########################")

    def test_2_get_apps(self):
        """ Test the exo_get_new_apps function when there are no apps to install.
            The dict of new apps should be empty. """

        print("################## Starting TEST 2 ########################")
        # set up Gateway for test
        GW = Gateway(self.gw_cfg, logging.DEBUG)
        print(GW)

        # set up engine for test
        E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
        print(E)

        # regen aptivator
        print(GW._http_regen(VENDOR_TOKEN))
        GW.ACTIVATION_INTERVAL = 2 # 2 seconds
        GW._set_uuid(UUID)
        GW.activate()
        self.assertEquals(GW.activated(), True)
        new_apps_dict = GW.get_and_parse_new_apps_to_name_version_dict()
        self.assertEquals(new_apps_dict, {})
        print("################## Ending TEST 2 ########################")

    def test_3_get_content_info(self):
        """ Test getting content info. """
        print("################## Starting TEST 3 ########################")
        # set up Gateway for test
        GW = Gateway(self.gw_cfg, logging.DEBUG)
        print(GW)

        # set up engine for test
        E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
        print(E)

        # regen aptivator
        print(GW._http_regen(VENDOR_TOKEN))
        GW.ACTIVATION_INTERVAL = 2 # 2 seconds
        GW._set_uuid(UUID)
        GW.activate()
        self.assertEquals(GW.activated(), True)

        response = GW._http_getContentInfo(self.test_tarball)
        self.assertEquals(response.code, 200)
        print("################## Ending TEST 3 ########################")


    def test_4_get_content(self):
        """ Test downloading actual content. """
        print("################## Starting TEST 4 ########################")
        # set up Gateway for test
        GW = Gateway(self.gw_cfg, logging.DEBUG)
        #GW.LOG.propagate = False
        print(GW)

        # set up engine for test
        E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
        #E.LOG.propagate = False
        print(E)

        # regen aptivator
        print(GW._http_regen(VENDOR_TOKEN))
        GW.ACTIVATION_INTERVAL = 2 # 2 seconds
        GW._set_uuid(UUID)
        GW.activate()
        self.assertEquals(GW.activated(), True)

        # now, grab content
        content = GW._http_getContent(self.test_tarball)
        self.assertEquals(content.code, 200)
        tar = tarball.NewTarball(self.test_tarball, content)
        tar.create_tarball_from_download()
        self.assertEquals(tar.is_tarball(), True)

        # cleanup test data
        tar.remove()
        self.assertEquals(os.path.exists(tar.path), False)
        print("################## Ending TEST 4 ########################")

    def test_5_base_install_from_downloaded_tarball(self):
        """ Test that Installer() and Engine() can properly extract tarball,
            update engine.config and create supervisor.d conf files. """

        print("################## Starting TEST 5 ########################")
        # set up Gateway for test
        GW = Gateway(self.gw_cfg, logging.DEBUG)
        #GW.LOG.propagate = False
        print(GW)

        # set up engine for test
        E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
        #E.LOG.propagate = False
        print(E)

        # regen aptivator
        print(GW._http_regen(VENDOR_TOKEN))
        GW.ACTIVATION_INTERVAL = 2 # 2 seconds
        GW._set_uuid(UUID)
        GW.activate()
        self.assertEquals(GW.activated(), True)

        # now, grab content and create tarball from it
        E.tar_extract_path = os.path.curdir
        content = GW._http_getContent(self.test_tarball)
        self.assertEquals(content.code, 200)
        tar = tarball.NewTarball(self.test_tarball, content)
        tar.create_tarball_from_download()

        # on Jenkins, we can't write to /tmp
        tar.extract_path = JENKINS_INSTALL_DIR
        if not os.path.exists(tar.extract_path):
            os.mkdir(tar.extract_path)

        print("Extracted app location: {!r}".format(tar.extract_location))
        self.assertEquals(tar.is_tarball(), True)
        self.assertEquals(self.test_tarball.split('.')[0], tar.name)
        self.assertEquals(self.test_tarball.split('.')[1].replace('v',''), tar.version)

        # set up for installation and install app
        spvsr_dir = os.path.abspath(os.path.join(E.tar_extract_path, 'sprvsr'))
        spvsr_conf_d_dir = os.path.join(spvsr_dir,'conf.d')
        E.sprvsr_conf_path = os.path.abspath(spvsr_conf_d_dir)
        if not os.path.exists(spvsr_dir):
            os.mkdir(spvsr_dir)
        if not os.path.exists(spvsr_conf_d_dir):
            os.mkdir(spvsr_conf_d_dir)

        print("TEST: Supervisor conf path: {!r}".format(E.sprvsr_conf_path))

        instlr = installer.Installer(tar.path, self.engine_cfg) # , base_install=True)
        instlr.sprvsr_conf_path = os.path.abspath(spvsr_conf_d_dir)
        instlr.install()
        self.assertEquals(instlr.code, 0)

        # cleanup after test
        # get rid of tarball
        tar.remove()
        self.assertEquals(tar.is_tarball(), False)

        # get rid of supervisor conf files
        spvsr_conf_files = glob.glob(os.path.join(E.sprvsr_conf_path, '*'))
        print("Checking for leftover files in: {!r}".format(os.path.join(E.sprvsr_conf_path,'*')))
        print("spvsr_conf_files left over from test: {!r}".format(spvsr_conf_files))
        for f in spvsr_conf_files:
            print("REMOVING FILE: {!r}".format(f))
            os.remove(f)

        print("REMOVING DIRECTORY: {!r}".format(spvsr_dir))
        # removes empty parent directory as well
        os.removedirs(spvsr_conf_d_dir)
        self.assertEquals(os.path.exists(spvsr_dir), False)

        # get rid of app in /tmp directory
        print("TAR EXTRACT LOCATION: {!r}".format(tar.extract_location))
        app_files = glob.glob(os.path.join(tar.extract_location, '*'))
        print("Checking for leftover files in: {!r}".format(os.path.join(tar.extract_location,'*')))
        print("app_files left over from test: {!r}".format(app_files))
        for f in app_files:
            print("REMOVING FILE: {!r}".format(f))
            os.remove(f)

        print("REMOVING DIRECTORY: {!r}".format(tar.extract_location))
        # removes empty parent directory as well
        os.removedirs(tar.extract_location)
        self.assertEquals(os.path.exists(tar.extract_location), False)
        print("################## Ending TEST 5 ########################")


    def test_6_base_install_from_directory(self):
        """ Test that Installer() and Engine() can properly install applications from directories. """

        print("################## Starting TEST 6 ########################")
        # set up Gateway for test
        GW = Gateway(self.gw_cfg, logging.DEBUG)
        #GW.LOG.propagate = False
        print(GW)

        # set up engine for test
        E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
        #E.LOG.propagate = False
        print(E)

        # regen aptivator
        print(GW._http_regen(VENDOR_TOKEN))
        GW.ACTIVATION_INTERVAL = 2 # 2 seconds
        GW._set_uuid(UUID)
        GW.activate()
        self.assertEquals(GW.activated(), True)

        # now, grab content and create tarball from it
        E.tar_extract_path = os.path.curdir
        content = GW._http_getContent(self.test_tarball)
        self.assertEquals(content.code, 200)
        tar = tarball.NewTarball(self.test_tarball, content)
        tar.create_tarball_from_download()

        # on Jenkins, we can't write to /tmp
        tar.extract_path = JENKINS_INSTALL_DIR
        if not os.path.exists(tar.extract_path):
            os.mkdir(tar.extract_path)

        tar.extract()
        print("Extracted app location: {!r}".format(tar.extract_location))
        self.assertEquals(tar.is_tarball(), True)
        self.assertEquals(self.test_tarball.split('.')[0], tar.name)
        self.assertEquals(self.test_tarball.split('.')[1].replace('v',''), tar.version)
        self.assertEquals(os.path.exists(tar.extract_location), True)

        # set up for installation and install app
        spvsr_dir = os.path.abspath(os.path.join(E.tar_extract_path, 'sprvsr'))
        spvsr_conf_d_dir = os.path.join(spvsr_dir,'conf.d')
        E.sprvsr_conf_path = os.path.abspath(spvsr_conf_d_dir)
        if not os.path.exists(spvsr_dir):
            os.mkdir(spvsr_dir)
        if not os.path.exists(spvsr_conf_d_dir):
            os.mkdir(spvsr_conf_d_dir)

        print("TEST: Supervisor conf path: {!r}".format(E.sprvsr_conf_path))

        instlr = installer.Installer(tar.path, self.engine_cfg) #, base_install=True)
        instlr.sprvsr_conf_path = os.path.abspath(spvsr_conf_d_dir)
        instlr.install()
        self.assertEquals(instlr.code, 0)

        # cleanup after test
        # get rid of tarball
        tar.remove()
        self.assertEquals(tar.is_tarball(), False)

        # get rid of supervisor conf files
        spvsr_conf_files = glob.glob(os.path.join(E.sprvsr_conf_path, '*'))
        print("Checking for leftover files in: {!r}".format(os.path.join(E.sprvsr_conf_path,'*')))
        print("spvsr_conf_files left over from test: {!r}".format(spvsr_conf_files))
        for f in spvsr_conf_files:
            print("REMOVING FILE: {!r}".format(f))
            os.remove(f)

        print("REMOVING DIRECTORY: {!r}".format(spvsr_dir))
        # removes empty parent directory as well
        os.removedirs(spvsr_conf_d_dir)
        self.assertEquals(os.path.exists(spvsr_dir), False)

        # get rid of app in /tmp directory
        print("TAR EXTRACT LOCATION: {!r}".format(tar.extract_location))
        app_files = glob.glob(os.path.join(tar.extract_location, '*'))
        print("Checking for leftover files in: {!r}".format(os.path.join(tar.extract_location,'*')))
        print("app_files left over from test: {!r}".format(app_files))
        for f in app_files:
            print("REMOVING FILE: {!r}".format(f))
            os.remove(f)

        print("REMOVING DIRECTORY: {!r}".format(tar.extract_location))
        # removes empty parent directory as well
        os.removedirs(tar.extract_location)
        self.assertEquals(os.path.exists(tar.extract_location), False)
        print("################## Ending TEST 6 ##########################")

    def test_7_compare_user_agent(self):
        """ Compare user_agent version created dynamically with actual Major and Minor versions."""

        print("################## Starting TEST 7 ########################")
        g = Gateway(TEST_CFG_FILE, logging.DEBUG)
        print ("User Agent: {!r}".format(g.user_agent))
        self.assertEquals(user_agent_prefix+GWE_VERSION, g.user_agent)
        print("################## Ending TEST 7 ##########################")

    def test_8_check_interface_argument(self):
        """ Check if interface option change prints serial no. for valid entry and warning for invalid entry."""
        print("################## Starting TEST 8 ########################")
        # Get the command line argument length and limit it to 2 args
        arg_count = len(sys.argv)
        while arg_count > 2:
            del(sys.argv[arg_count-1])
            arg_count = arg_count-1
        # Test valid entry

        sys.argv[1] = "-i {}".format(IFACE)

        parser = cli.parse_args(sys.argv[1])
        self.assertEquals(parser,False)
        # test invalid entry
        sys.argv[1] = "-i non_existing_iface"
        parser = cli.parse_args(sys.argv[1])
        self.assertEquals(parser,True)
        # set back to empty entries
        sys.argv[1] = "-i ''"
        sys.argv.append("-u ''")
        parser = cli.parse_args(sys.argv)
        self.assertEquals(parser,True)
        print("################## Ending TEST 8 ##########################")

    def test_9_validate_tarball(self):
        """ Check the tarball for naming conventions."""

        print("################## Starting TEST 9 ########################")
        # Testing valid name -> Std version testing forward compatibility
        result, app_name, app_version = Tarball.parse_filename('test_app.v1.2.3.tar.gz')
        self.assertTrue(result)
        self.assertEquals(app_name, 'test_app')
        self.assertEquals(app_version, '1.2.3')

        # Testing valid name -> Std version testing backwards compatibility
        result, app_name, app_version = Tarball.parse_filename('test_app.v1.tar.gz')
        self.assertTrue(result)
        self.assertEquals(app_name, 'test_app')
        self.assertEquals(app_version, '1')

        # Testing valid name -> special characters in version
        result, app_name, app_version = Tarball.parse_filename('test_app.v11_1-0-RC19.tar.gz')
        self.assertTrue(result)
        self.assertEquals(app_name, 'test_app')
        self.assertEquals(app_version, '11_1-0-RC19')

        # Testing valid name -> 'v' in version number
        result, app_name, app_version = Tarball.parse_filename('test_app.v1-2#v3.tar.gz')
        self.assertTrue(result)
        self.assertEquals(app_name, 'test_app')
        self.assertEquals(app_version, '1-2#v3')

        # Testing valid name -> 3 '.' in version number
        result, app_name, app_version = Tarball.parse_filename('test_app.v1.2.3.4.tar.gz')
        self.assertTrue(result)
        self.assertEquals(app_name, 'test_app')
        self.assertEquals(app_version, '1.2.3.4')

        # Testing invalid name -> missing version field
        result, app_name, app_version = Tarball.parse_filename('test_app.tar.gz')
        self.assertFalse(result)

        # Testing invalid name -> missing app name field
        result, app_name, app_version = Tarball.parse_filename('.v1.tar.gz')
        self.assertFalse(result)

        # Testing invalid name -> missing app name and version field
        result, app_name, app_version = Tarball.parse_filename('..tar.gz')
        self.assertFalse(result)

        # Testing invalid name -> missing version number
        result, app_name, app_version = Tarball.parse_filename('test_app.v.tar.gz')
        self.assertFalse(result)

        print("################## Ending TEST 9 ##########################")

    def test_10_custom_application_validate_And_createtarball(self):
        """ Test that custom application using json file read and make installer tarball
        """
        print("################## Starting TEST 10 ########################")
        change_path= os.getcwd()
        tar_creation_path= os.chdir('/tmp')
        tmpdir = tempfile.mkdtemp()
        # create empty files to put into tarball
        test_files = ['install.sh','test_gwe.py','exclude.this','test_app.json']
        for f in test_files:
            with open(f, 'w') as tmp:
                pass

        # define valid config to later convert to json
        test_conf = {
            "name":"Test_App",
            "version":"1",
            "includes":[
                "install.sh",
                "test_gwe.py"
            ],
            "excludes": ['exclude.this'],
            "model": "GatewayEngine_V1",
            "vendor": "exosite",
            "pre_build_cmds": ['echo "This is fun."'],
            "post_build_cmds": []
        }

        # dump test_conf to json file
        with open('test_app.json', 'w') as tmp:
            tmp.write(json.dumps(test_conf, indent=2))

        # print to console for debug
        print(open('test_app.json').read())


        tar = tarball.NewTarball(None, 'test_app.json')
        # with self.assertRaises(tarball.SectionMissing):
        tar.create_tarball_from_build_file()
        print tar.path
        self.assertEquals(tar.is_tarball(), True)
        # cleanup after test
        tar.remove()
        self.assertEquals(tar.is_tarball(), False)
        for f in test_files:
            os.unlink(f)

        shutil.rmtree(tmpdir)
        os.chdir(change_path)

        print("################## Ending TEST 10 ########################")


    def test_11_custom_application_verify_raise_on_invalid_json(self):
        """ Test that custom application using json file read and make installer tarball
        """
        print("################## Starting TEST 11 ########################")
        change_path= os.getcwd()
        tar_creation_path= os.chdir('/tmp')
        tmpdir = tempfile.mkdtemp()

        missing_test_configs = [
            {},
            {"name": "name_only"},
            {"pre_build_cmds": []}
        ]
        for test_conf in missing_test_configs:
            print("Testing incomplete config: {}".format(test_conf))
            # dump test_conf to json file
            with open('test_app.json', 'w') as tmp:
                tmp.write(json.dumps(test_conf, indent=2))
            # print to console for debug
            print(open('test_app.json').read())

            tar = tarball.NewTarball(None, 'test_app.json')
            with self.assertRaises(tarball.SectionMissing):
                tar.create_tarball_from_build_file()
            os.unlink('test_app.json')

        invalid_test_configs = [
            # invalid name
            {
                "name":["Test_App"],
                "version":"1",
                "includes":[
                    "install.sh",
                    "test_gwe.py"
                ],
                "excludes": ['exclude.this'],
                "model": "GatewayEngine_V1",
                "vendor": "exosite",
                "pre_build_cmds": ['echo "This is fun."'],
                "post_build_cmds": []
            },
            # invalid version
            {
                "name":["Test_App"],
                "version":1, # should be string
                "includes":[
                    "install.sh",
                    "test_gwe.py"
                ],
                "excludes": ['exclude.this'],
                "model": "GatewayEngine_V1",
                "vendor": "exosite",
                "pre_build_cmds": ['echo "This is fun."'],
                "post_build_cmds": []
            },
            # invalid pre_build_cmds
            {
                "name":["Test_App"],
                "version":"1",
                "includes":[
                    "install.sh",
                    "test_gwe.py"
                ],
                "excludes": ['exclude.this'],
                "model": "GatewayEngine_V1",
                "vendor": "exosite",
                "pre_build_cmds": 'echo "This is fun."',
                "post_build_cmds": []
            },
        ]

        for test_conf in invalid_test_configs:
            print("Testing invalid config: {}".format(test_conf))
            # dump test_conf to json file
            with open('test_app.json', 'w') as tmp:
                tmp.write(json.dumps(test_conf, indent=2))
            # print to console for debug
            print(open('test_app.json').read())

            tar = tarball.NewTarball(None, 'test_app.json')
            with self.assertRaises(tarball.SectionInvalid):
                tar.create_tarball_from_build_file()
            os.unlink('test_app.json')

            os.chdir(change_path)

        print("################## Ending TEST 11 ########################")

    def test_12_dataport_overriding_verification(self):
        """ Test to verify if custom dataport definitions are executed. """
        print("################## Starting TEST 12 ########################")
        p = ConfigParser.RawConfigParser()
        p.read(TEST_CFG_FILE)
        p.set(GatewayCfgSects.Dataports, GatewayCfgOpts.EngineReport, 'app_loader_report')
        p.set(GatewayCfgSects.Dataports, GatewayCfgOpts.EngineFetch, 'app_loader_fetch')
        with open(TEST_CFG_FILE, 'w') as cfg_file:
            p.write(cfg_file)
        GW = Gateway(TEST_CFG_FILE, logging.DEBUG)
        self.assertEquals(GW.res_engine_report, 'app_loader_report')
        self.assertEquals(GW.res_engine_fetch, 'app_loader_fetch')

        print("################## Ending TEST 12 ##########################")

if __name__ == '__main__':
    unittest.main()
