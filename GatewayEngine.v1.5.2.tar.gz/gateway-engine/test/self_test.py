#!/usr/bin/env pythopn

import unittest, sys
import subprocess, shlex

class SelfTest(unittest.TestCase):

    def setup(self):

        pass

    def teardown(self):

        pass

    def test_01_uname(self):
        """Just get a system imprint to the log before running any tests.

        From uname manpage:
         -a      Behave as though all of the options -mnrsv were specified.
         -m      print the machine hardware name.
         -n      print the nodename (the nodename may be a name that the system is known by to a communications network).
         -p      print the machine processor architecture name.
         -r      print the operating system release.
         -s      print the operating system name.
         -v      print the operating system version.
        """
        for opt in ['a', 'm', 'n', 'r', 's', 'p', 'v' ]:
            cmd = "uname -{}".format(opt)
            try:
                print(cmd)
                result = subprocess.check_call(shlex.split(cmd), stdout=sys.stdout, stderr=sys.stdout)
                print(cmd)
                self.assertEquals(0,result)
            except subprocess.CalledProcessError as exc:
                self.fail("Test '{}' FAILED: {}".format(cmd, exc.message))

    def test_02_json(self):
        cmd = 'import json'
        try:
            print(cmd)
            exec(cmd)
            self.assertTrue(True)
            print("Test '{}' PASSED".format(cmd))
        except ImportError as exc:
            ("Test '{}' FAILED: {}".format(cmd, exc.message))

    def test_03_requests(self):
        cmd = 'import requests'
        try:
            print(cmd)
            exec(cmd)
            self.assertTrue(True)
            print("Test '{}' PASSED".format(cmd))
        except ImportError as exc:
            ("Test '{}' FAILED: {}".format(cmd, exc.message))

    def test_04_twisted(self):
        cmd = 'import twisted'
        try:
            print(cmd)
            exec(cmd)
            self.assertTrue(True)
            print("Test '{}' PASSED".format(cmd))
        except ImportError as exc:
            ("Test '{}' FAILED: {}".format(cmd, exc.message))

    def test_05_exo(self):
        cmd = 'import exo'
        try:
            print(cmd)
            exec(cmd)
            self.assertTrue(True)
            print("Test '{}' PASSED".format(cmd))
        except ImportError as exc:
            ("Test '{}' FAILED: {}".format(cmd, exc.message))

    def test_06_GatewayEngine(self):
        cmd = 'import GatewayEngine'
        try:
            print(cmd)
            exec(cmd)
            self.assertTrue(True)
            print("Test '{}' PASSED".format(cmd))
        except ImportError as exc:
            ("Test '{}' FAILED: {}".format(cmd, exc.message))

    def test_07_gmq(self):
        cmd = 'import gmq'
        try:
            print(cmd)
            exec(cmd)
            self.assertTrue(True)
            print("Test '{}' PASSED".format(cmd))
        except ImportError as exc:
            ("Test '{}' FAILED: {}".format(cmd, exc.message))



    def test_08_gdc(self):
        cmd = "gdc --version"
        try:
            subprocess.check_call(shlex.split(cmd))
            print("Test '{}' PASSED".format(cmd))
        except:
            self.fail("Test '{}' FAILED".format(cmd))

    def test_09_gwe(self):
        cmd = "gwe --version"
        try:
            subprocess.check_call(shlex.split(cmd))
        except:
            self.fail("Test '{}' FAILED".format(cmd))

    def test_10_gmq(self):
        cmd = "gmq --version"
        try:
            subprocess.check_call(shlex.split(cmd))
            print("Test '{}' PASSED".format(cmd))
        except:
            self.fail("Test '{}' FAILED".format(cmd))


