"""***************************************************************************************
* Project           : Gateway Engine
*
* Module name       : test_engine.py
*
* Author            : Will Charlton
*
* Date created      : 
*
* Purpose           : Testing basic GatewayEngine functionality.
*
* Revision History  :
*
* Date              Author          Description
*------------      -----------     -------------------------------------------------------
* Aug 2, 2016      Prakash S      Changed tests to use ENV variables instead of files.

|**************************************************************************************"""

"""
	Test execution instructions:

	$ pwd
		.../gateway-engine/
	$ ls 
		... etc ...
		/test
	$ export VENDOR="vendor_name"
	$ export VENDOR_TOKEN="40_char_secret_token"
	$ python -m unittest discover test

"""

# pylint: disable=R0201

import unittest
from exo.device import Device, DeviceCfgOpt, DeviceCfgSect
from GatewayEngine.GatewayEngine import Engine, \
                                        EngineCfgSects, \
                                        EngineCfgOpts, \
                                        GatewayCfgSects, \
                                        GatewayCfgOpts
import ConfigParser, os, platform, logging

USER_AGENT = 'Test_GatewayEngine'
MODEL = 'aptivator_v1'
UUID = 'ap:ti:va:to:rt:st'
IFACE = 'en0' if 'Darwin' == platform.system() else 'eth0'
TEST_CFG_FILE = 'test.cfg'

# These are set, first, in the Jenkins Job Configuration for APtivator,
# then by the test_aptivator.sh jenkins script. This keeps the vendor
# and vendor token info out of the git repo.
print("PWD: {0}".format(os.path.abspath(os.path.curdir)))
#VENDOR = open('WHITELABEL_VENDOR', 'r').readline().strip()
VENDOR = os.environ['VENDOR']
#VENDOR_TOKEN = open('WHITELABEL_TOKEN', 'r').readline().strip()
VENDOR_TOKEN = os.environ['VENDOR_TOKEN']
print("VENDOR = {0}".format(VENDOR))
print("VENDOR TOKEN = {0}".format(VENDOR_TOKEN))


class test_simple_cfg_file(unittest.TestCase):
	""" Unittest to test a simple cfg file. """
	@classmethod
	def setUpClass(cls):
		# file should be ConfigParser compatible.
		open(TEST_CFG_FILE, 'wb').write("""[device]
cik = ''
model = {0}
vendor = {1}
uuid = {2}
iface = {3}

[dataports]
usage_report = usage_report
engine_report = engine_report
engine_fetch = engine_fetch
device_info = device_info
fetch_status = fetch_status
update_interval = update_interval

""".format(MODEL, VENDOR, UUID, IFACE))
		print("Using config file: {}".format(
			open(TEST_CFG_FILE, 'r').read()))

		# it is probably wrong, philosophically, to used code you intend to
		# test in order to set up for that test, but I'm doing it anyways

	@classmethod
	def tearDownClass(cls):
		""" Remove test file. """
		os.remove(TEST_CFG_FILE)

	def setUp(self):
		""" Setup for test. """
		self.test_tarball = 'test_app.v1.tar.gz'
		self.engine_cfg = 'engine_test.cfg'
		self.gw_cfg = 'gw_test.cfg'

		# create engine config file		
		open(self.engine_cfg, 'wb').write("""[{0}]
counter = 0
dummy = 5

[{1}]
{2} = {3}
{4} = {5}
""".format(EngineCfgSects.Apps,
			EngineCfgSects.Device,
			EngineCfgOpts.UpdateInterval,43200,
			EngineCfgOpts.UserAgent,USER_AGENT))

		# create Gateway cfg file
		open(self.gw_cfg, 'wb').write("""[{0}]
{1} = {2}
{3} = {4}
{5} = {6}
{7} = {8}
{9} = {10}

[{11}]
{12} = {13}
{14} = {15}
{16} = {17}
{18} = {19}
{20} = {21}
{22} = {23}
""".format(DeviceCfgSect.Device,
			DeviceCfgOpt.Cik, '',
			DeviceCfgOpt.Model, MODEL,
			DeviceCfgOpt.Vendor, VENDOR,
			DeviceCfgOpt.Uuid, UUID,
			'iface', IFACE,
			GatewayCfgSects.Dataports,
			GatewayCfgOpts.UsageReport, GatewayCfgOpts.UsageReport,
			GatewayCfgOpts.UpdateInterval, GatewayCfgOpts.UpdateInterval,
			GatewayCfgOpts.EngineReport, GatewayCfgOpts.EngineReport,
			GatewayCfgOpts.EngineFetch, GatewayCfgOpts.EngineFetch,
			GatewayCfgOpts.DeviceInfo, GatewayCfgOpts.DeviceInfo,
			GatewayCfgOpts.FetchStatus, GatewayCfgOpts.FetchStatus))
		print("Using config file: {}".format(
			open(self.gw_cfg, 'r').read()))

	def tearDown(self):
		""" Remove test file. """
		os.remove(self.engine_cfg)
		os.remove(self.gw_cfg)

	def test_1_apploader_instaniation(self):
		""" Just try to instantiate with cfg file. """
		
		self.assertIsNotNone(Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg))

	# @unittest.skip("Skipping until refactored.")
	def test_2_set_update_interval(self):
		""" Test update_interval set and get methods. """
		E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
		E.set_update_interval(20)
		self.assertEquals(E.update_interval(), 20)

	# @unittest.skip("Skipping until refactored.")
	def test_3_set_user_agent(self):
		""" Test user_agent set and get methods. """
		E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
		E.set_user_agent('test_user_agent-v1.2')
		self.assertEquals(E.user_agent(), 'test_user_agent-v1.2')

	# @unittest.skip("Skipping until refactored.")
	def test_4_set_apps(self):
		""" Test set_apps set and get methods. """
		E = Engine(self.engine_cfg, logging.DEBUG, gateway_cfg_file=self.gw_cfg)
		E.LOG_LEVEL = 0
		#E.LOG.debug("test_set_apps: Starting apps: {!r}".format(E.apps()), 1)
		E.set_apps([{'counter': 1, 'dummy': 5}])
		#E.LOG.debug("test_set_apps: After update, apps: {!r}".format(E.apps()), 1)
		# print(open(self.engine_cfg).readlines())
		self.assertEquals(E.apps(), [{'counter': 1, 'dummy': 5}])
		# make sure they're int's, not strings...
		self.assertNotEquals(E.apps(), [{'counter': "1", 'dummy': "5"}])

if __name__ == '__main__':
	unittest.main()
