'''

To run these tests, run from test dir with:
`python -m unittest discover -t .. -p test_gwe*`
'''
# pylint: disable=W0312
import unittest
import tarfile
import os
import random
import string
from shutil import rmtree
from GatewayEngine import utils

def createInstaller(files_to_create, outputName):
    # Creates the array of files listed in files_to_create.  files_to_create is
    # a dictionary whose key will be the files names and whose value.contents are the 
    # contents of the file.  File will be left in cwd
    
    # Create a temp directory to work with.
    directory = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(12))
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Create files
    for file_n, values in files_to_create.iteritems():
        filename = os.path.join(directory, file_n)
        values['path'] = filename
        #filePaths.append(filename)
        with open(filename, 'w+') as f:
            if values['contents'] != None:
                # print("Writing" + values['contents'])
                f.write(values['contents'])

    # tar all of these things up
    tar = tarfile.open(outputName, "w:gz")
    tar.add(directory, arcname='')
    tar.close()

    # remove tmp directory
    rmtree(directory)



class TestAppVerification(unittest.TestCase):

    def test_invalid_tarball(self):
        # is_tarball test should have failed
        junkName = 'junk.v1.tar.gz'
        with open(junkName, 'w+'):
            pass
        self.assertFalse(utils.check_tarball(junkName, show_results = False, cleanup_tmp = False)['is_tarball']['success'])
        os.remove(junkName)
        
    
    def test_install_sh_exists(self):
        installerName = 'validInstall.v1.tar.gz'
        createInstaller({'install.sh':{'contents':''}, 'supervisor.conf':{'contents':''}}, installerName)
        self.assertTrue(utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)['install_sh_exists']['success'])
        os.remove(installerName)
    
    def test_no_install_sh_exists(self):
        installerName = 'noInstallSh.v1.tar.gz'
        createInstaller({'supervisor.conf':{'contents':''}}, installerName)
        results = utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)
        self.assertFalse(results['install_sh_exists']['success'])
        self.assertFalse(results['has_supervisord_section']['success'])
        os.remove(installerName)

    def test_no_options_in_supervisord_section(self):
        installerName = 'noInstallSh.v1.tar.gz'
        createInstaller({'supervisor.conf':{'contents':'[supervisord]'}}, installerName)
        results = utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)
        self.assertFalse(results['supervisord_section_has_options']['success'])
        os.remove(installerName)

    def test_options_in_supervisord_section(self):
        installerName = 'noInstallSh.v1.tar.gz'
        createInstaller({'supervisor.conf':{'contents':'[supervisord]\ncommand = nothing'}}, installerName)
        results = utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)
        self.assertTrue(results['supervisord_section_has_options']['success'])
        os.remove(installerName)

    def test_eol_fail(self):
        installerName = 'badEol.v1.tar.gz'
        createInstaller({'install.sh':{'contents':'cats\r\nhate dogs'}, 'supervisor.conf':{'contents':''}}, installerName)
        self.assertFalse(utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)['no_crnl_in_install_sh']['success'])
        os.remove(installerName)
    
    def test_shebang_does_exist(self):
        installerName = 'badEol.v1.tar.gz'
        createInstaller({'install.sh':{'contents':'#!'}, 'supervisor.conf':{'contents':''}}, installerName)
        self.assertTrue(utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)['shebang_present_at_start_of_install_sh_file']['success'])
        os.remove(installerName)
        
    def test_shebang_does_not_exist(self):
        installerName = 'badEol.v1.tar.gz'
        createInstaller({'install.sh':{'contents':'hi'}, 'supervisor.conf':{'contents':''}}, installerName)
        self.assertFalse(utils.check_tarball(installerName, show_results = False, cleanup_tmp = False)['shebang_present_at_start_of_install_sh_file']['success'])
        os.remove(installerName)
        
    def test_file_name_invalid_full(self):
        self.assertFalse(utils.isFileNameValid('badFileName.tar.gz'))
        
    def test_filename_valid_multiple(self):
        ''' 
        Test a bunch of other cases
        '''
        # valid case
        self.assertIsNotNone(utils.isFileNameValid('asdf.v1.tar.gz'))
        # valid w/ numbers
        self.assertIsNotNone(utils.isFileNameValid('as12df.v1.tar.gz'))
        # valid w/ specials in version
        self.assertIsNotNone(utils.isFileNameValid('as12df.v1_2-4a.tar.gz'))
        # valid with _
        self.assertIsNotNone(utils.isFileNameValid('as_df.v1.tar.gz'))
        # invalid with not tar.gz extension
        self.assertIsNone(utils.isFileNameValid('asdf.zip'))
        # Invalid with no extension
        self.assertIsNone(utils.isFileNameValid('asdfzip'))
    
    
if __name__ == '__main__':
    unittest.main()

