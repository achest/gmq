#!/usr/bin/env python
# pylint: disable=I0011,W0312,R0903,W0232,C1001

from constants import DEFAULT_ENGINE_CONF_FILE, DEFAULT_GATEWAY_CONF_FILE

try:
    # this import gives access to AtomicConfigParser name
    # for isinstance() checks
    #from AtomicConfigParser import AtomicConfigParser
    # this import provides a uniform way of creating parsers
    from AtomicConfigParser import AtomicConfigParser as CfgParser
    USING_ATOMIC_CONFIG_PARSER = True
except ImportError:
    from ConfigParser import RawConfigParser as CfgParser
    USING_ATOMIC_CONFIG_PARSER = False

def parse_args(args):

    import argparse, os, sys, textwrap, logging
    import utils
    from subprocess import check_output

    parser = argparse.ArgumentParser(
        prog="gwe",
        formatter_class=argparse.RawTextHelpFormatter)

    # add arguments
    parser.add_argument(
        "-v",
        "--version",
        action='store_true',
        help="Print the current GWE version."
    )

    parser.add_argument(
        "-p",
        "--path",
        action='store_true',
        help="Print the installation path to GWE python package."
    )

    parser.add_argument(
        "-e",
        "--engine-conf",
        action='store_true',
        help="Print the contents of the Engine.config file."
    )

    parser.add_argument(
        "-g",
        "--gateway-cfg",
        action='store_true',
        help="Print the contents of the Gateway.cfg file."
    )

    parser.add_argument(
        "-C",
        "--gateway-cik",
        action='store_true',
        help="Print the GWE cik."
    )

    parser.add_argument(
        "-M",
        "--mac-address",
        metavar="IFACE",
        type=str,
        help=textwrap.dedent('''\
            Print the MAC address of the provided interface (e.g. 'eth0',
            'ppp0', etc).

            This is the serial number (uuid) gwe would use as
            if it were configured with the provided interface.''')
    )

    parser.add_argument(
        "-o",
        "--once",
        action='store_true',
        help="Do not continuously run GWE. Run once and exit."
    )

    parser.add_argument(
        "-x",
        "--create-buildfile",
        action='store_true',
        help="Create buildfile."
    )

    parser.add_argument(
        "-y",
        "--build-app",
        metavar="JSON_BUILD_FILE",
        type=str,
        help=textwrap.dedent('''\
            Build a Custom Gateway Application (CGA) tarball with
            a JSON build file tailored to your application.
            The JSON build file completely describes how a CGA
            is built. It lists all necessary files for the app to
            run on the gateway, the install.sh file and the
            supervisor.conf file (if applicable).

            To initialize your CGA repository with an empty/default
            JSON build file, use the --create-buildfile cli option.''')
    )

    parser.add_argument(
        "-I",
        "--install-apps",
        metavar="APP_TARBALL",
        nargs="+",
        help="Provide the path to a tarball or a list of paths to tarballs to install."
    )

    parser.add_argument(
        "-c",
        "--set-cik",
        metavar="CIK",
        type=str,
        help="Set the GWE cik with provided value."
    )

    parser.add_argument(
        "-m",
        "--set-model",
        metavar="MODEL",
        type=str,
        help="Set the GWE model with provided value."
    )

    parser.add_argument(
        "-r",
        "--set-vendor",
        metavar="VENDOR",
        type=str,
        help="Set the GWE vendor with provided value."
    )

    parser.add_argument(
        "-P",
        "--set-product-id",
        metavar="PRODUCT_ID",
        type=str,
        help="Configure GWE with your Murano Product ID with provided value."
    )

    parser.add_argument(
        "-u",
        "--set-uuid",
        metavar="UUID",
        type=str,
        help="Set the GWE uuid/serial-number with provided value."
    )

    parser.add_argument(
        "-G",
        "--use-gateway-cfg",
        metavar="PATH_TO_CFG",
        type=str,
        help='''Provide the path to a Gateway.cfg file to use instead of the default:

{}
'''.format(DEFAULT_GATEWAY_CONF_FILE)
    )

    parser.add_argument(
        "-E",
        "--use-engine-cfg",
        metavar="PATH_TO_CFG",
        type=str,
        help='''Provide the path to an Engine.config file to use instead of the default:

{}
'''.format(DEFAULT_ENGINE_CONF_FILE)
    )

    parser.add_argument(
        "-i",
        "--set-iface",
        metavar="IFACE",
        type=str,
        help=textwrap.dedent('''\
            Set the hardware interface (e.g. eth0, wlan0, ppp0, etc.)
            for GWE to use to get a MAC address as its
            uuid/serial-number.''')
    )

    parser.add_argument(
        "-l",
        "--set-act-retry-interval",
        metavar="INTERVAL_SECONDS",
        type=str,
        help=textwrap.dedent('''\
            Set activation retry interval in seconds. The activation
            retry interval is the amount of time gwe waits in between
            successive activation requests.''')
    )

    parser.add_argument(
        "-d",
        "--set-debug-level",
        type=str,
        choices=['DEBUG','INFO','WARNING', 'ERROR', 'CRITICAL'],
        help="Set the runtime logging level of GWE."
    )

    parser.add_argument(
        "-t",
        "--set-update-interval",
        metavar="UPDATE_INTERVAL",
        type=float,
        help="Set period (in seconds) of time between GWE check-ins."
    )

    parser.add_argument(
        "-a",
        "--set-user-agent",
        metavar="USER_AGENT",
        type=str,
        help="Set the GWE User-Agent HTTP header."
    )

    parser.add_argument(
        "-n",
        "--app-name",
        type=str,
        help="The name of the Custom Gateway Application. This is the NAME in NAME.v1.tar.gz."
    )
    parser.add_argument(
        "-s",
        "--app-version",
        type=str,
        help="The version of the Custom Gateway Application. This is the VERSION in NAME.vVERSION.tar.gz"
    )

    parser.add_argument(
        "--download-latest",
        metavar="RELEASE_AREA",
        nargs=1,
        help=textwrap.dedent('''\
            Download the latest release of Gateway Engine.

            Currently there are several release areas to choose from:

             * gmq-master:      The most common and popular release of
                                Gateway Engine that contains the
                                store-and-forward Gateway Message
                                Queuing (GMQ) server.
             * gmq-dev:         Same as gmq-master, but built from a
                                development branch used for testing and
                                development. Not intended for Production use.
             * baseline-master: This is a stripped-down version of Gateway
                                Engine that contains only a minimal feature-set.
             * baseline-dev:    Same as baseline-master, but built from a
                                development branch used for testing and
                                development. Not intended for Production use.

            Example usage:

                $ gwe --download-latest gmq-master
            ''')
    )

    parser.add_argument(
        "-w",
        "--check-buildfile",
        metavar="BUILDFILE",
        type=str,
        help="Checks the gwe.build file for common problems. Does not detect all problems."
    )
    parser.add_argument(
        "-z",
        "--check-tarball",
        metavar="TARBALL",
        type=str,
        help="Checks GWE tarball for things like structure, optional elements."
    )
    args = parser.parse_args()

    log_level = logging.INFO
    if args.set_debug_level:
        log_level = eval('logging.'+args.set_debug_level)

    class STDOUTFilter(logging.Filter):
        """
            Logging filter for command line interface
            that is to filter messages below logging.INFO.
            Any message less than logging.INFO will not
            be logged to STDOUT.
        """
        def __init__(self, exclusive_maximum, name=""):
            super(STDOUTFilter, self).__init__(name)
            self.max_level = exclusive_maximum

        def filter(self, record):
            #non-zero return means we log this message
            return True if record.levelno >= self.max_level else False

    class STDERRFilter(logging.Filter):
        """
            Logging filter for command line interface
            that is to filter messages above logging.INFO.
            Any message greater than logging.INFO will not
            be logged to STDERR.
        """
        def __init__(self, exclusive_maximum, name=""):
            super(STDERRFilter, self).__init__(name)
            self.max_level = exclusive_maximum

        def filter(self, record):
            #non-zero return means we log this message
            return True if record.levelno < self.max_level else False

    CLI_OUT = logging.getLogger('cli')
    CLI_OUT.setLevel(log_level)
    h_stdout = logging.StreamHandler(sys.stdout)
    h_stdout.setLevel(log_level)
    h_stdout.addFilter(STDOUTFilter(logging.INFO))
    h_stderr = logging.StreamHandler(sys.stderr)
    h_stderr.setLevel(log_level)
    h_stderr.addFilter(STDERRFilter(logging.INFO))
    h_stdout.setFormatter(logging.Formatter('%(message)s'))
    h_stderr.setFormatter(logging.Formatter('%(message)s'))
    CLI_OUT.addHandler(h_stdout)
    CLI_OUT.addHandler(h_stderr)
    # CLI_OUT.setLevel(logging.NOTSET)
    CLI_OUT.propagate = False

    NO_RUN = False
    # set flag to decide if user warning to be printed
    warning_status = True

    engine_config = DEFAULT_ENGINE_CONF_FILE if not args.use_engine_cfg else args.use_engine_cfg
    gateway_cfg = DEFAULT_GATEWAY_CONF_FILE if not args.use_gateway_cfg else args.use_gateway_cfg

    print_gateway_cfg = False
    if args.version:
        from GatewayEngine import GWE_VERSION
        from GatewayEngine import DC_VERSION
        CLI_OUT.info("device-client: "+DC_VERSION)
        CLI_OUT.info("gateway-engine: "+GWE_VERSION)
        NO_RUN = True
    if args.path:
        CLI_OUT.info(os.path.abspath(os.path.dirname(__file__)))
        NO_RUN = True
    if args.engine_conf:
        CLI_OUT.info(open(engine_config, 'r').read())
        NO_RUN = True
    if args.gateway_cfg:
        print_gateway_cfg = True
        NO_RUN = True
    if args.gateway_cik:
        p = CfgParser()
        p.read(gateway_cfg)
        CLI_OUT.info(p.get('device', 'cik'))
        NO_RUN = True
    if args.mac_address:
        from GatewayEngine import Gateway as G
        import logging
        logging.disable(logging.CRITICAL)
        print(G.get_mac_address(args.mac_address))
        print_gateway_cfg = False
        NO_RUN = True
    if args.set_cik:
        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'cik', args.set_cik)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)
        print_gateway_cfg = True
        NO_RUN = True
    if args.set_model:
        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'model', args.set_model)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)
        print_gateway_cfg = True
        NO_RUN = True
    if args.set_vendor:
        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'vendor', args.set_vendor)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)
        print_gateway_cfg = True
        NO_RUN = True
    if args.set_product_id:
        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'model', args.set_product_id)
        p.set('device', 'vendor', args.set_product_id)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)
        NO_RUN = True
        print_gateway_cfg = True
    if args.set_uuid:
        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'uuid', args.set_uuid)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)
        print_gateway_cfg = True
        NO_RUN = True
    if args.set_iface:
        from platform import system
        import subprocess
        from GatewayEngine import DisableLogger, Gateway

        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'iface', args.set_iface.strip())
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)

        # read the file /proc/net/dev
        if 'Darwin' != system():
            with open('/proc/net/dev','r') as procnetdev:
                # put the content to list
                ifacelist = procnetdev.read().split('\n')
            # remove 2 lines header
            ifacelist.pop(0)
            ifacelist.pop(0)
        else:
            process = subprocess.Popen(
                        "ifconfig {}".format(args.set_iface).split(),
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT
            )
            ifacelist = process.stdout.read().split('\n')
            process.wait()

        # loop to check each line
        for line in ifacelist:
            ifacedata = line.replace(' ','').split(':')
            # check the data have 2 elements
            if len(ifacedata) == 2:
                # Compare user configured interface with available options
                ifname = ifacedata[0]
                if ifname == args.set_iface.strip(' '):
                    with DisableLogger():
                        sn = Gateway.get_mac_address(ifname)
                    CLI_OUT.debug("Found interface {!r} with MAC address (serial/uuid): {!r}".format(
                        ifname, sn)
                    )
                    warning_status = False

        if warning_status:
            CLI_OUT.info(
                "User configured interface is not found on system! Please clear the uuid and use valid interface."
            )
        print_gateway_cfg = True
        NO_RUN = True
    if args.set_act_retry_interval:
        p = CfgParser()
        p.read(gateway_cfg)
        p.set('device', 'activation_retry_interval', args.set_act_retry_interval)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(gateway_cfg)
        else:
            with open(gateway_cfg, 'wb') as cfg:
                p.write(cfg)
        NO_RUN = True
    if args.set_update_interval:
        p = CfgParser()
        p.read(engine_config)
        p.set('device', 'update_interval', args.set_update_interval)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(engine_config)
        else:
            with open(engine_config, 'wb') as cfg:
                p.write(cfg)
        NO_RUN = True
    if args.set_user_agent:
        p = CfgParser()
        p.read(engine_config)
        p.set('device', 'user_agent', args.set_user_agent)
        if USING_ATOMIC_CONFIG_PARSER:
            p.write(engine_config)
        else:
            with open(engine_config, 'wb') as cfg:
                p.write(cfg)
        NO_RUN = True

    if args.install_apps:
        from installer import Installer
        debug_level = logging.DEBUG if args.set_debug_level else logging.INFO
        CLI_OUT.setLevel(debug_level)

        CLI_OUT.debug("Installing app(s): {!r}".format(args.install_apps[0:]))

        for app in args.install_apps:
            gwe_dir = os.path.abspath(os.path.dirname(__file__))
            engine_cfg_path = os.path.join(gwe_dir, 'Engine.config')
            instlr = Installer(app, engine_cfg=engine_cfg_path)
            instlr.install()
            if instlr.code == 0:
                CLI_OUT.debug("{!r}: {!r}".format(app, instlr.stdout))
                CLI_OUT.info("Installing app {!r} succeeded.".format(app))
            else:
                CLI_OUT.debug("{!r}: {!r}".format(app, instlr.stdout))
                CLI_OUT.info("Installation of app {!r} FAILED: code: {!r}".format(app, instlr.code))
        NO_RUN = True

    if args.app_name:
        CLI_OUT.info(args.app_name)
        NO_RUN = True

    if args.app_version:
        CLI_OUT.info(args.app_version)
        NO_RUN = True

    if args.download_latest:
        CLI_OUT.debug("Downloading latest release of Gateway Engine from {} release area...".format(args.download_latest[0]))
        import requests
        redirect = requests.get(
            'https://s3-us-west-2.amazonaws.com/exosite-client-downloads/gateway-engine-release-area/{}/latest.lnk'.format(args.download_latest[0])
        )
        link = redirect.content.strip()
        CLI_OUT.debug("Downloading: {}".format(link))
        release_name = link.split('/')[-1]
        tball = requests.get(link)
        open(release_name, 'wb').write(tball.content)
        CLI_OUT.info(release_name)
        NO_RUN = True

    if args.create_buildfile:
        utils.create_build_file(
            app_name=args.app_name,
            app_version=args.app_version,
            model=args.set_model,
            uuid=args.set_uuid,
            vendor=args.set_vendor,
            iface=args.set_iface
        )
        NO_RUN = True

    if args.build_app:
        from GatewayEngine import tarball
        new_tarball = tarball.NewTarball(None, args.build_app)
        new_tarball.LOG.handlers = []
        new_tarball.LOG.addHandler(h_stdout)
        new_tarball.LOG.addHandler(h_stderr)
        new_tarball.LOG.setLevel(CLI_OUT.level)

        new_tarball.LOG.propagate = False
        utils.check_build_file(args.build_app, verbose=True)
        #create tar ball
        if new_tarball.create_tarball_from_build_file():
            CLI_OUT.debug("\nApplication tarball is created at following path...")
            CLI_OUT.info(new_tarball.path)
            utils.check_tarball(
                new_tarball.path,
                cleanup=False,
                cleanup_tmp=False,
                show_results=CLI_OUT.level <= logging.DEBUG
            )
        else:
            CLI_OUT.warning("Could not create tarball.")
        NO_RUN = True

    if args.check_buildfile:
        CLI_OUT.info(utils.check_build_file(args.check_buildfile, verbose=True))
        NO_RUN = True

    if args.check_tarball:
        utils.check_tarball(args.check_tarball, cleanup=False, verbose=True)
        NO_RUN = True

    if print_gateway_cfg:
        CLI_OUT.info(open(gateway_cfg, 'r').read())

    if NO_RUN:
        return warning_status

    if os.path.exists(engine_config):
        from GatewayEngine import Engine
        E = Engine(engine_config, log_level)
        E.start(once=args.once)
    else:
        CLI_OUT.error("Unable to start Gateway. {!r} not found!".format(engine_config))

    return args


def main():
    """
        Entry point for Gateway Engine process.
    """
    import sys
    parser = parse_args(sys.argv[1:])

if __name__ == '__main__':
    main()
