#!/usr/bin/env python
# pylint: disable=I0011,W0312,R0903,W0232,C1001

import socket
from time import sleep
from datetime import datetime
from platform import system
import subprocess, \
    os, sys, socket, \
    fcntl, struct, json, \
    logging, tarball, \
    xmlrpclib, textwrap
from exo.device import Device, DeviceCfgSect, DeviceCfgOpt
from constants import EngineCfgOpts, EngineCfgSects, GatewayCfgSects, GatewayCfgOpts
from constants import ROOT_LOGGER, formatter, DEFAULT_GATEWAY_CONF_FILE
from ConfigParser import NoOptionError
import traceback

try:
    # this import gives access to AtomicConfigParser name
    # for isinstance() checks
    #from AtomicConfigParser import AtomicConfigParser
    # this import provides a uniform way of creating parsers
    from AtomicConfigParser import AtomicConfigParser as CfgParser
    USING_ATOMIC_CONFIG_PARSER = True
except ImportError:
    from ConfigParser import RawConfigParser as CfgParser
    USING_ATOMIC_CONFIG_PARSER = False


from __init__ import __version__ as GWE_VERSION# pylint: disable=I0011,W0403
from exo.__init__ import __version__ as DC_VERSION
from constants import user_agent_prefix

logging.basicConfig(format='%(asctime)s %(message)s')
GW_LOGGER_NAME = ROOT_LOGGER+'.g'
EN_LOGGER_NAME = ROOT_LOGGER+'.e'

class DisableLogger():
    """Class used for disabling logging for specific context."""
    def __enter__(self):
        logging.disable(logging.CRITICAL)
    def __exit__(self, a, b, c):
        logging.disable(logging.NOTSET)

class Gateway(Device):
    """ Object containing Gateway-specific variables and methods.

        Gateway doesn't require any configuration file settings other
        than the ones needed by Device().
    """
    def __init__(self, cfg_file, log_level):
        self.user_agent = user_agent_prefix+GWE_VERSION
        self._uuid = ''
        self.gateway_cfg = cfg_file
        self.GwLOG = logging.getLogger(GW_LOGGER_NAME)
        self.GwLOG.setLevel(log_level)
        self.GwLOG.propagate = True
        self.GwLOG.setLevel(log_level)
        Device.__init__(self, self.user_agent, cfg_file)
        self._set_uuid(self.getSerialNumber())
        Device.__init__(self, self.user_agent, cfg_file)
        self.usage_log = self.ifaces_log_file # inherited from exo.device.Device
        self._usage_report = ''
        if log_level <= logging.DEBUG:
            self.set_http_debug(True)

        # define dataports, use Device() class's config parser
        self.res_usage_report = self._cfg_parser.get(
            GatewayCfgSects.Dataports, GatewayCfgOpts.UsageReport)
        self.res_engine_report = self._cfg_parser.get(
            GatewayCfgSects.Dataports, GatewayCfgOpts.EngineReport)
        self.res_engine_fetch = self._cfg_parser.get(
            GatewayCfgSects.Dataports, GatewayCfgOpts.EngineFetch)
        self.res_device_info = self._cfg_parser.get(
            GatewayCfgSects.Dataports, GatewayCfgOpts.DeviceInfo)
        self.res_fetch_status = self._cfg_parser.get(
            GatewayCfgSects.Dataports, GatewayCfgOpts.FetchStatus)
        self.res_update_interval = self._cfg_parser.get(
            GatewayCfgSects.Dataports, GatewayCfgOpts.UpdateInterval)

    def gwe_debug_upload(self, debug_info):
        """Sends debug information to 'fetch_status' dataport."""
        resp = self.http_write(self.res_fetch_status, debug_info)
        if resp.code == 200 or resp.code == 204:
            self.GwLOG.debug("Successfully sent stacktrace to dataport.")
        else:
            self.GwLOG.error("Error sending stacktrace to dataport.")
        return

    def iface(self):
        """
            Get the hardware internet interface name from
            the Gateway.cfg file.
        """
        p = CfgParser()
        p.read(self.gateway_cfg)
        iface = None
        try:
            iface = p.get('device', 'iface')
        except NoOptionError as err:
            self.GwLOG.error("Can't find iface in {}: {} :: {}".format(
                self.gateway_cfg, err, open(self.gateway_cfg,'r').read()),
                exc_info=True
            )
            self.gwe_debug_upload(traceback.format_exc())

        return iface

    def getSerialNumber(self):
        """ Get Serial Number of Gateway.

            If the Gateway.cfg file has the 'uuid' option set,
            the value provided will be used as the serial number
            for the gateway.

            If the 'iface' option is set, the serial number of
            the gateway will be the MAC address of the hardware
            interface provided (i.e. eth0, en0, ppp0, etc.).

            If neither 'uuid' or 'iface' options are set in the
            Gateway.cfg file, GWE will not be able to run because
            it will have no serial number with which to provision
            itself with Exosite.
        """
        # start with the one that's in the config file
        iface = self.iface()
        uuid = self.uuid()
        self.GwLOG.debug("Starting with interface: {}, uuid: {}".format(
            iface, uuid))
        if  "''" != uuid and '' != uuid and not uuid is None:
            self.GwLOG.info("Using {} config file entry for serial number value"
            .format(self.gateway_cfg))
            sn = uuid
        elif iface and '' != iface and "''" != iface:
            self.GwLOG.info("Using iface {} MAC address for serial number value"
            .format(iface))
            sn = self.get_mac_address(iface)
            p = CfgParser()
            p.read(self.gateway_cfg)
            p.set(DeviceCfgSect.Device, DeviceCfgOpt.Uuid, sn)
            if USING_ATOMIC_CONFIG_PARSER:
                p.write(self.gateway_cfg)
            else:
                with open(self.gateway_cfg, 'wb') as cfg:
                    p.write(cfg)
        else:
            sys.stderr.write("Please specify either uuid or iface in "
            "Gateway.cfg.\nUse 'gwe --help' for more information about "
            "selecting either a uuid or interface.\n")
            sys.exit(-1)
        self.GwLOG.debug("Using serial number: {}".format(sn))
        return sn

    def ip_addr(self, iface):
        """ Returns a string that represents the ip address in octet form of the
            iface parameter given.

            Example:
                $ print(ip_addr('ppp0'))
                '142.54.82.147'

                $ print(ip_addr('eth0'))
                '192.168.0.50'
        """
        ipaddrs = []
        if 'Darwin' == system():
            import netifaces
            addrs = netifaces.ifaddresses(iface)
            ipaddrs = [ addr.get('addr') for addr in addrs[netifaces.AF_INET] ]
            self.GwLOG.debug("On darwin, found IP addresses for '{}': {}"
            .format(iface, ipaddrs))
        else:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                ipaddrs = [ socket.inet_ntoa(fcntl.ioctl(
                    s.fileno(),
                    0x8915,  # SIOCGIFADDR
                    struct.pack('256s', iface[:15])
                )[20:24]) ]
            except IOError as err:
                if err.errno == 19:
                    self.GwLOG.error("Device: {0} not configured."
                        .format(iface), exc_info=True
                    )
                elif err.errno == 99:
                    self.GwLOG.error("Device: {0} not connected."
                        .format(iface), exc_info=True
                    )
                else:
                    self.GwLOG.critical("Unknown error {!r}: {!r}"
                        .format(iface, err), exc_info=True
                    )
                    raise
        return ipaddrs

    @staticmethod
    def get_mac_address(ifname):
        """ Get MAC address from OS. """

        if GW_LOGGER_NAME in logging.Logger.manager.loggerDict.keys():
            static_logger = logging.getLogger(GW_LOGGER_NAME)
        else:
            static_logger = logging.getLogger(GW_LOGGER_NAME)
            static_logger.setLevel(logging.DEBUG)
            streamh = logging.StreamHandler(sys.stdout)
            streamh.setFormatter(formatter)
            static_logger.addHandler(streamh)
            static_logger.propagate = False

        mac = "NO MAC FOUND!"
        static_logger.debug("Trying to find mac address.")
        if 'Darwin' == system():
            import netifaces
            try:
                link_obj = netifaces.ifaddresses(ifname).get(netifaces.AF_LINK)
                static_logger.debug("On darwin, found AF_LINK object: {}"
                    .format(link_obj)
                )
                mac = link_obj[0].get('addr')
            except ValueError as exc:
                static_logger.debug("Interface not found on system: {}"
                    .format(exc), exc_info=True
                )
        else:
            static_logger.info("Getting MAC address from interface {}"
            .format(ifname))
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                info = fcntl.ioctl(s.fileno(), 0x8927, struct.pack('256s', ifname[:15]))
                mac = ':'.join(['%02x'.upper() % ord(char) for char in info[18:24]])
                static_logger.info("Found MAC {} on interface {}".format(mac.upper(), ifname))
            except IOError as err:
                if err.errno == 19:
                    static_logger.error("Device: {0} not configured."
                        .format(ifname), exc_info=True
                    )
                elif err.errno == 99:
                    static_logger.error("Device: {0} not connected."
                        .format(ifname), exc_info=True
                    )
                else:
                    static_logger.critical("Unknown error: {!r}"
                        .format(err), exc_info=True
                    )
                    raise
        static_logger.info("MAC Address: {}".format(mac))
        return mac.upper()

    def run_cmd(self, cmd):
        """ Run a shell command and return its output.

            If raised, catches OSError and returns the error message.

            Examples:
                free_space = self.run_cmd('free')
                ifconfig = self.run_cmd('ifconfig '+self.iface())
        """

        stdout = ''
        try:
            process = subprocess.Popen(
                        cmd.split(" "),
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT
            )
            for line in process.stdout.readlines():
                stdout += line
                self.GwLOG.debug(line)
            process.wait()
        except OSError as err:
            stdout = str(err)
        return stdout.strip()

    def usage_report(self):
        """ Gets the usage report from

                Device.interfaces.interface_report()

            and JSONifies it.
        """
        report = self.interface_report()
        return json.dumps(report)

    @staticmethod
    def network_connected(host="8.8.8.8", port=53, timeout=3):
        """
            Host: 8.8.8.8 (google-public-dns-a.google.com)
            OpenPort: 53/tcp
            Service: domain (DNS/TCP)
        """
        try:
            socket.setdefaulttimeout(timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
            return True
        except Exception as ex: # pylint: disable=I0011,W0703
            if 51 == ex.errno:
                pass
            else:
                print("GWE.network_connected: {0}".format(ex))
        return False


    def exo_report(self, apps_report):
        """ Exosite communication function that updates
            dataports with report data.
        """
        apps_dict = dict(apps=apps_report)

        # TODO: the throttling scheme I (Will) worked up has the following problems
        # 1. It uses a flat-file db that needs to be read in its entirety
        #    any time a throttle check is made (which is for every call).
        #    Fix this by using an actual database
        # 2. It's current state is hard-coded to designate a cik as throttle-worthy
        #    if it made more than 60 calls in the last hour. While this is a good idea
        #    for catching run-away conditions, it should atleast be tunable.

        ifaces_throttled_ciks = self.throttle_check()
        if len(ifaces_throttled_ciks) > 0:
            apps_dict['throttled_ciks'] = ifaces_throttled_ciks
        apps_json = json.dumps(apps_dict)
        write_handler = self.http_write_multiple({
                self.res_usage_report: self.usage_report(),
                self.res_engine_report: apps_json,
                self.res_device_info: json.dumps( self.device_info() )
            }
        )
        if write_handler.success:
            self.GwLOG.debug("Successfully sent usage and apps report {!r}"
                .format(write_handler)
            )
        elif write_handler.authorized:
            self.GwLOG.critical("No or invalid CIK. Setting self NOT "
                "activated: {!r}".format(write_handler)
            )
            self._set_activated(False)
        else:
            self.GwLOG.debug("Unable to process write request: {!r}"
                .format(write_handler)
            )

    def device_info(self):
        """ Sends device information to device_info dataport.

            Contents include:
               * uname -a output for kernel and os info
               * ip addresses for gdc and gwe configured interfaces
               * df output for current disk space usage
               * free output for memory usage
        """
        ip_addresses = {}
        # get addr for gwe configured iface
        ip_addresses[self.iface()] = self.ip_addr(self.iface())
        # iterate over what's in the gdc.ifaces config
        for ip in self.ifaces:
            ip_addresses[ip] = self.ip_addr(ip)

        return {
            'uname': self.run_cmd('uname -a'),
            'ipaddrs': json.dumps(ip_addresses),
            'df': self.run_cmd('df'),
            'free': self.run_cmd('free')
       }

    def exo_fetch_new_apps_list(self):
        """ Returns a list of tarball names to look for in content area. After
            successfully reading the engine_fetch dataport, we clear it.

            fetch dataport format and examples:
                * {"install": [{"name": "new_app.v1.tar.gz"},
                             {"name": "newer_app.v3.tar.gz"}]}

                * {"install": [{"name": "test_app2.v3.tar.gz"}]}

        """
        resp = self.http_read([self.res_engine_fetch])
        if resp.success:
            self.GwLOG.debug("Successfully retrieved new app_loader info: {!r}"
                .format(resp.body)
            )
            apps_list = []
            if resp.body.split('=')[0] == self.res_engine_fetch\
                and resp.body.split('=')[1] != '':
                apps_list_of_dicts = resp.body.split('=')[1]
                self.GwLOG.debug('apps_list_of_dicts: {!r}'
                    .format(apps_list_of_dicts)
                )
                install_dict = {}
                try:
                    install_dict = json.loads(apps_list_of_dicts)
                except ValueError as err:
                    self.GwLOG.warning("Can't load JSON: {!r}"
                        .format(err), exc_info=True
                    )
                    self.gwe_debug_upload(traceback.format_exc())

                apps_list = [a for a in install_dict.get('install')] \
                                if install_dict.get('install') is not None else []
                # for app_dict in install_dict.get('install'):
                #     apps_list.append(app_dict['name'])

                # now, clear the dataport
                resp = self.http_write(self.res_engine_fetch, '')
                if resp.code == 200 or resp.code == 204:
                    self.GwLOG.debug("Successfully cleared engine_fetch: {!r}"
                        .format(str(resp))
                    )
                else:
                    self.GwLOG.error("Error clearing engine_fetch "
                        "dataport: {!r}".format(str(resp))
                    )

            return apps_list
        else:
            self.GwLOG.debug("Unable to process 'engine_fetch' read "
                "request: {!r}".format(str(resp))
            )
            return []

    def exo_get_update_interval(self, device):
        """ Fetches new update interval from update_interval dataport, then
        clears the dataport. If we're unable to retrieve any new values or if
        it isn't a valid value, just return the old one. """
        dataport = self.res_update_interval
        new_value = device.update_interval()
        read_handler = self.http_read([dataport])
        if read_handler.success:
            self.GwLOG.debug("Successfully retrieved data from {!r}: {!r}"
                .format(dataport, read_handler.body)
            )
            update_interval = read_handler.body
            self.GwLOG.info("received: {!r}".format(update_interval))

            # now make sure we actually got a new value for update_interval
            if len(update_interval.split('=')) == 2:
                if update_interval.split('=')[1] != '':
                    update_interval = update_interval.split('=')[1]
                    self.GwLOG.debug("setting for new update interval: {!r}"
                        .format(update_interval)
                    )
                    # now, clear the dataport
                    write_handler = self.http_write(dataport, '')
                    if write_handler.success:
                        self.GwLOG.debug("Successfully cleared engine_fetch: "
                            "{!r}".format(str(write_handler))
                        )
                    else:
                        self.GwLOG.error("Error clearing engine_fetch "
                            "dataport: {!r}".format(str(write_handler))
                        )

                    # don't support insane update intervals
                    try: # in case the value in the dataport isn't a base-10 number
                        if int(update_interval) >= 0:
                            new_value = int(update_interval)
                        else:
                            self.GwLOG.error("Refusing to acknowledge insane "
                                "update interval: {!r}".format(update_interval)
                            )
                    except ValueError as err:
                        self.GwLOG.error(
                            "Dataport contained unusable content: {!r}, err: "
                            "{!r}".format(update_interval, err), exc_info=True
                        )
                        self.gwe_debug_upload(traceback.format_exc())
                else:
                    self.GwLOG.debug("No new update interval to set: {!r}"
                        .format(update_interval)
                    )
            else:
                self.GwLOG.debug("Improperly formatted data in dataport: {!r}"
                    .format(update_interval)
                )
        else:
            self.GwLOG.debug("Unable to process {!r} read request: {!r}"
                .format(dataport, read_handler)
            )
        return new_value

    def get_and_parse_new_apps_to_name_version_dict(self):
        """ Calls self.exo_fetch_new_apps_list() and parses the tarball names
        into a python dict containing

            fetch dataport format:
                {'tarball_name': {'name': <name>, 'version': <version>}}
        """
        apps_list = self.exo_fetch_new_apps_list()
        self.GwLOG.info("New apps list: {!r}".format(apps_list))
        tarball_dict = {}
        for app in apps_list:
            tar = tarball.ExistingTarball(app.get('name'))
            tarball_dict[app.get('name')] = {'name': tar.name,
                                             'version': tar.version
                                            }
        return tarball_dict

    def activate(self):
        """ This function runs until a successful activate call
        is made. """
        self.GwLOG.critical("Starting activation loop...")
        while not self.activated():
            self.activate_device()
            self.GwLOG.debug("Activation status - {!r} - using config: {!r}"
                .format(self.activated(), open(self.gateway_cfg, 'r').read())
            )
            if not self.activated():
                self.GwLOG.debug("Activation failed. Trying again in {!r} "
                    "seconds.".format(self._activation_retry_interval)
                )
                sleep(self._activation_retry_interval)

class Engine(object):
    """ Engine defines the main program loop for Gateway Engine. """
    def __init__(self, engine_cfg_file, log_level, gateway_cfg_file=DEFAULT_GATEWAY_CONF_FILE):
        self._update_interval = None
        self._user_agent = None
        self.cfg_parser = CfgParser(allow_no_value=True)
        self.cfg_file = engine_cfg_file
        # supervisord server
        self.server = xmlrpclib.Server('http://localhost:9001/RPC2')
        self.sprvsr_conf_path = '/etc/supervisor/conf.d'
        self.LOG = logging.getLogger(ROOT_LOGGER+'.e')
        self.LOG.setLevel(log_level)
        self.LOG.propagate = True
        self.G = Gateway(gateway_cfg_file, self.LOG.level)
        self._apps = []
        self.update_self_from_cfg()

    def __repr__(self):
        return 'user_agent: {!r}, update_interval: {!r}, apps: {!r}'.format(
            self._user_agent, self._update_interval, self._apps)

    def update_interval(self):
        """ Protected member getter. """
        return self._update_interval

    def set_update_interval(self, interval):
        """ Protected member setter. Sets instance member and cfg file."""
        self._update_interval = interval
        self.dump_to_cfg(
            EngineCfgSects.Device, EngineCfgOpts.UpdateInterval,
            self._update_interval
        )

    def user_agent(self):
        """ Protected member getter. """
        return self._user_agent

    def set_user_agent(self, user_agent):
        """ Protected member setter. Sets instance member and cfg file."""
        self._user_agent = user_agent
        self.dump_to_cfg(
            EngineCfgSects.Device, EngineCfgOpts.UserAgent,
            self._user_agent
        )

    def apps(self):
        """ Protected member getter.
            List of dicts. Like this: [{'counter': 1}, {'ntp_updater': 1}] """
        return self._apps

    def set_apps(self, apps):
        """ Protected member setter. Sets instance member and cfg file."""
        self.LOG.debug("Incoming apps: {!r}".format(apps))
        self._apps = apps
        # update cfg file
        for app in self.apps():
            self.LOG.debug("app: {!r}".format(app))
            for key, value in app.iteritems():
                self.LOG.debug("key, value: {!r} {!r}".format(key, value))
                self.dump_to_cfg(EngineCfgSects.Apps, key, value)

    def proc_parser(self, runtime_info):
        """ Parses supervisor.getAllProcessInfo() and returns a dictionary."""
        runtime_apps_list = []
        for proc in runtime_info:
            runtime_dict = {}
            if 'RUNNING' == proc['statename']:
                # proc['description'] = 'pid 12162, uptime 0:01:38'
                # throw away pid, just grab uptime, get rid of extra whitespace...
                uptime = proc['description'].split(',')[1].replace('uptime', '')

                runtime_dict[proc['name']] = {'uptime': uptime,
                                              'status': proc['statename'],
                                              'exitstatus': proc['exitstatus']
                                             }

                self.LOG.debug("{!r}\t\t\t{!r}\t{!r}\t{!r}".format(
                    proc['name'], proc['statename'], proc['description'],
                    proc['exitstatus']))

            else:
                runtime_dict[proc['name']] = {'uptime': proc['description'],
                                              'status': proc['statename'],
                                              'exitstatus': proc['exitstatus']
                                             }

                self.LOG.debug("{!r}\t\t\t{!r}\t{!r}\t{!r}".format(
                    proc['name'], proc['statename'], proc['description'],
                    proc['exitstatus']))
            runtime_apps_list.append(runtime_dict)
        return runtime_apps_list

    def apps_report(self):
        """ Returns a dict of apps that contains runtime info from
        supervisord. """
        runtime_info = self.supervisor_get_all_process_info()
        parsed_rt_info = self.proc_parser(runtime_info)
        # runtime_apps = []

        supervisor_apps = [proc.keys()[0] for proc in parsed_rt_info]
        app_loader_apps = [app.keys()[0] for app in self.apps()] # the name is the key()

        self.LOG.info("PROC_INFO: {!r}".format(parsed_rt_info))
        self.LOG.info("SPVSR_INFO: {!r}".format(supervisor_apps))
        self.LOG.info("APPS_INFO: {!r}".format(app_loader_apps))
        # if the app name from getAllProcessInfo() isn't in list of apps we
        # have in self.apps(), we have an app that is under supervisor control,
        # but app_loader isn't aware of it.this shouldn't ever happen, but in
        # case it does, let's send it up to exosite for our awareness...

        # compare the two lists self.apps() and supervisor_apps
        # for every element in supervisor_apps not in self.apps(),
        # mark as 'rogue' an send it to exosite with the rest...

        for app in list(set(supervisor_apps).symmetric_difference(app_loader_apps)):
            if app != 'gwe': # GatewayEngine definitely not a rogue app...
                for proc in parsed_rt_info:
                    if app == proc.keys()[0]:
                        # all we're doing is renaming the key
                        new_name = 'ROGUE_APP-'+app
                        proc[new_name] = proc.pop(app)
                        # add version info
                        proc[new_name]['version'] = '?'
            else:
                for proc in parsed_rt_info:
                    if app == proc.keys()[0]:
                        # set the app_loader version
                        proc[app]['version'] = "-".join(
                            ['GDC_'+DC_VERSION,'GWE_'+GWE_VERSION]
                        )

        self.LOG.info("Updated PROC_INFO: {!r}".format(parsed_rt_info))
        # set the rest of supervisor process info.
        # i.e. The ones not marked as 'rogue' and not app_loader.
        for app in self.apps():
            self.LOG.debug("app: {!r}".format(app))
            app_name = app.keys()[0]
            for proc in parsed_rt_info:
                proc_name = proc.keys()[0]
                if app_name == proc_name:
                    version = app[app_name]
                    proc[proc_name]['version'] = version

        self.LOG.info("Updated PROC_INFO: {!r}".format(parsed_rt_info))
        # runtime_apps.append(parsed_rt_info)
        return parsed_rt_info


    def update_self_from_cfg(self):
        """ Updates Device instance with values from cfg. """
        self.cfg_parser.read(self.cfg_file)
        self.set_update_interval(self.cfg_parser.getfloat(EngineCfgSects.Device,
                                                          EngineCfgOpts.UpdateInterval))
        # get list of apps from config file
        apps = self.cfg_parser.options(EngineCfgSects.Apps)
        # build array of app dicts
        apps_array = []
        for app in apps:
            app_dict = {app: self.cfg_parser.get(EngineCfgSects.Apps, app)}
            self.LOG.debug("Adding new app_dict: {!r}".format(app_dict))
            apps_array.append(app_dict)
        self.LOG.debug("Setting New Apps: {!r}".format(apps_array))
        self.set_apps(apps_array)

    def dump_to_cfg(self, section, option, value):
        """ Utility to dump configuration data to the instance cfg file. """
        if os.path.exists(self.cfg_file):
            self.cfg_parser.read(self.cfg_file)
            if self.cfg_parser.has_section(section):
                self.cfg_parser.set(section, option, value)
            else:
                self.LOG.debug("Unable to dump: '{!r}' '{!r}' '{!r}'"
                    .format(section, option, value)
                )
                return # don't bother writing it, we didn't update anything.
            if USING_ATOMIC_CONFIG_PARSER:
                self.cfg_parser.write(self.cfg_file)
            else:
                with open(self.cfg_file, 'wb') as cfg:
                    self.cfg_parser.write(cfg)

    def supervisor_get_all_process_info(self):
        """
            Connect to supervisord and return the getAllProcessInfo()
            data.

            If supervisor is not installed and/or not running, a message
            will be logged and an empty list returned.
        """
        proc_info = []
        try:
            proc_info = self.server.supervisor.getAllProcessInfo()
        except socket.error as err:
            self.LOG.info("Unable to connect to supervisord: {}".format(err),
                exc_info=True
            )
        return proc_info

    def supervisor_stop_app(self, app):
        """ Method to stop a supervisor-controlled application. """
        # try-block for stopping process
        try:
            self.server.supervisor.stopProcess(app, True)
        except xmlrpclib.Fault as err:
            if err.faultCode == 10:
                self.LOG.error("Tried to stop {!r}: {!r}"
                    .format(app, str(err)), exc_info=True
                )
            else:
                self.LOG.critical("Problem stopping process {!r}"
                    .format(str(err)), exc_info=True
                )
        except socket.error as err:
            self.LOG.info("Unable to connect to supervisord: {}"
                .format(err), exc_info=True
            )

    def supervisor_start_app(self, app):
        """ Method to stop a supervisor-controlled application. """
        # try-block for starting process
        try:
            self.server.supervisor.startProcess(app, True)
            self.LOG.debug("(Re)starting {!r} successful!".format(app))
        except xmlrpclib.Fault as err:
            if err.faultCode == 10:
                self.LOG.error("Tried to start {!r}: {!r}"
                    .format(app, str(err)), exc_info=True
                )
            else:
                self.LOG.critical("Problem starting process {!r}"
                    .format(str(err)), exc_info=True
                )
        except socket.error as err:
            self.LOG.info("Unable to connect to supervisord: {}"
                .format(err), exc_info=True
            )

    def supervisor_restart_app(self, app):
        """ Method to stop a supervisor-controlled application. """
        # try-block for starting process
        try:
            self.server.supervisor.startProcess(app, True)
            self.LOG.debug("(Re)starting {!r} successful!".format(app))
        except xmlrpclib.Fault as err:
            if err.faultCode == 10:
                self.LOG.error("Tried to start {!r}: {!r}"
                    .format(app, str(err)), exc_info=True
                )
            else:
                self.LOG.critical("Problem starting process {!r}"
                    .format(str(err)), exc_info=True
                )
        except socket.error as err:
            self.LOG.info("Unable to connect to supervisord: {}"
                .format(err), exc_info=True
            )

    def supervisor_reload_config(self):
        """ Method for making supervisor reload its config files. """
        self.LOG.debug("Reloading supervisor config files...")
        try:
            self.server.supervisor.reloadConfig()
        except socket.error as err:
            self.LOG.info("Unable to connect to supervisord: {}"
                .format(err), exc_info=True
            )

    def supervisor_add_process_group(self, group):
        """ Method to add a process group (new application) to supervisord
        control. """
        self.LOG.debug("Adding {!r} Process Group to supervisor..."
        .format(group))
        try:
            self.server.supervisor.addProcessGroup(group)
        except socket.error as err:
            self.LOG.info("Unable to connect to supervisord: {}"
                .format(err), exc_info=True
            )

    def loop(self, once):
        tar_extract_path = tarball.Tarball('.').extract_path
        while True:
            try:
                self.LOG.info("Current data/time: {!r}".format(
                    str(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))))

                # the possibility exists for our local CIK to be corrupted, lost, etc.
                # each time through the loop, check to make sure we can still
                # communicate with Exosite
                if not self.G.activated():
                    self.G.activate()

                # ################################
                # Check for new apps
                # ################################

                new_apps_dict = self.G.get_and_parse_new_apps_to_name_version_dict()
                self.LOG.info("new_apps_dict: {!r}".format(new_apps_dict))
                total_bytes = 0
                for app in new_apps_dict.keys():
                    r = self.G._http_getContentInfo(app)

                    # If we got a response with some content
                    if r.code == 200:
                        app_size = int(r.body.split(',')[1])
                        total_bytes += app_size
                        new_apps_dict[app]['install'] = True
                    else:
                        self.LOG.debug("response code: {!r}".format(r.code))
                        self.LOG.warning("Error getting content info for {!r}"
                            .format(app)
                        )

                # #############################################################
                # Determine if we have enough disk space to install new apps
                # #############################################################

                statvfs = os.statvfs(tar_extract_path)
                bytes_free = statvfs.f_frsize*statvfs.f_bfree
                if bytes_free < total_bytes:
                    self.LOG.debug("ERROR: Not enough free space in {!r}! "
                        "Not downloading apps!".format(tar_extract_path)
                    )
                    self.LOG.debug("Total new content bytes: {!r}, Free Space "
                        "on {!r}: {!r}"
                        .format(total_bytes, tar_extract_path, bytes_free)
                    )
                    self.G.gwe_debug_upload('NO_FREE_SPACE')
                    continue

                # ################################
                # Get New Apps from Exosite
                # ################################

                for app in new_apps_dict.keys():
                    response = self.G._http_getContent(app)
                    self.LOG.debug("Content length of {!r}: {!r}"
                        .format(app, len(r.body))
                    )
                    # received a response with some content
                    if response.code == 200:
                        self.LOG.debug("Received update for {!r}".format(app))

                        self.LOG.debug("Updating {!r}".format(app))
                        new_tarball = tarball.NewTarball(app, response)
                        new_tarball.create_tarball_from_download()
                        new_apps_dict[app]['install_path'] = new_tarball.path
                    else:
                        self.LOG.debug("Error downloading content for "
                        "{!r}: {!r}".format(app, r.code))

                # ################################
                # Install New Apps
                # ################################

                for app in new_apps_dict.keys():

                    from installer import Installer
                    instlr = Installer(new_apps_dict[app]['install_path'],
                    self.cfg_file)
                    instlr.install()
                    if instlr.code == 0:
                        new_apps_dict[app]['install_successful'] = True
                        self.LOG.debug("STDOUT for {!r}: {!r}"
                            .format(app, instlr.stdout)
                        )
                        self.LOG.info("Installing app '{!r}' succeeded."
                            .format(app)
                        )
                        app_to_add = {}
                        app_to_add[new_apps_dict[app]['name']] = new_apps_dict[app]['version']
                        self.apps().append(app_to_add)
                        self.set_apps(self.apps())
                        # remove the old tarball since it was successfully
                        # created and extracted
                        cleaner = tarball.ExistingTarball(new_apps_dict[app]['install_path'])
                        cleaner.remove()
                        cleaner.remove_install_package()
                    else:
                        new_apps_dict[app]['install_successful'] = False
                        self.LOG.debug("{!r}: {!r}".format(app, instlr.stdout))
                        self.LOG.debug("Installation of app '{!r}' FAILED: code: {!r}".format(
                            app, instlr.code)
                        )


                    write_handler = self.G.http_write(self.G.res_fetch_status, instlr.stdout)
                    if write_handler.success:
                        self.LOG.error("Successfully sent installer stdout to "
                            "'fetch_status' dataport: {}".format(write_handler)
                        )
                    else:
                        self.LOG.error("Failed to write installer stdout to "
                            "'fetch_status' dataport: {}".format(write_handler)
                        )

                # ################################
                # Determine installation success
                # (Re)Start App
                # ################################


        # Programmer's Note:
        #     At this point in the program loop, we're done installing every new application.
        #     If the installed application is one that has been re-installed,
        #     we need to stop it and reload its configuration file (in case it has changed).
        #     If the installed application is a brand-new install, we need to have
        #     supervisor read its configuration.
        #     Since server.supervisor.reloadConfig() restarts all applications, we can't
        #     use it and expect it to re-load a single application's config.



                for app in new_apps_dict.keys():
                    super_apps = [ proc['group'] for proc in
                                  self.supervisor_get_all_process_info() ]
                    self.LOG.debug("Applications under supervisor control: {!r}".format(
                        super_apps))
                    if new_apps_dict[app]['install_successful']:
                        self.LOG.debug("new_apps_dict: {!r}".format(new_apps_dict))
                        self.LOG.debug("self.apps(): {!r}".format(self.apps()))
                        app_name = new_apps_dict[app]['name']
                        if "gwe" == app_name:
                            # we're doing an OTAU of Gateway Engine itself
                            # therefor we offload the responsibility of restarting
                            # gwe to the OTAU installer
                            self.LOG.warning("OTAU of gwe detected. Not restarting. OTAU installer must do the restart.")
                        elif app_name in super_apps:
                            self.LOG.debug("Restarting {!r}".format(new_apps_dict[app]['name']))
                            self.supervisor_stop_app(new_apps_dict[app]['name'])
                            self.supervisor_reload_config()
                            self.supervisor_start_app(new_apps_dict[app]['name'])
                        else:
                            self.LOG.debug("Not stopping {!r} since it is a new application. \
                                            Starting for the first time...".format(
                                                new_apps_dict[app]['name']))
                            self.supervisor_reload_config()
                            # this is a little hacky for my tastes, but here it goes
                            # in the event of a one-off app (one that runs once and doesn't need
                            # supervisor control), there won't be a supervisord configuration file
                            # in /etc/supervisor/conf.d. But when you try to add a process group
                            # without a conf file, you throw an exception. If we catch this exception,
                            # we're accomodating one-off apps.
                            # TODO: do this better.
                            try:
                                self.supervisor_add_process_group(new_apps_dict[app]['name'])
                            except xmlrpclib.Fault as rpcfault:
                                self.LOG.warning("Not adding one-off app as process group: {!r}"
                                    .format(str(rpcfault)), exc_info=True
                                )
                    else:
                        self.LOG.debug("Install of {!r} failed.".format(app))

                p_info_b4_reload = self.supervisor_get_all_process_info()

                self.LOG.debug("Process stats before reload :: >")
                for proc in p_info_b4_reload:
                    self.LOG.debug("{!r}\t\t\t{!r}\t{!r}\t{!r}".format(
                        proc['name'], proc['statename'], proc['description'], proc['exitstatus']))
                self.supervisor_reload_config()

                p_info_aftr_reload = self.supervisor_get_all_process_info()
                self.LOG.debug("New Process stats:: >")
                for proc in p_info_aftr_reload:
                    self.LOG.debug("{!r}\t\t{!r}\t{!r}\t{!r}".format(
                        proc['name'], proc['statename'], proc['description'], proc['exitstatus']))


                self.set_update_interval(
                    self.G.exo_get_update_interval(self))

                self.G.exo_report(self.apps_report())
            except Exception as exc:
                self.LOG.critical("Caught general loop exception: {!r}"
                    .format(exc), exc_info=True
                )
                self.G.gwe_debug_upload(traceback.format_exc())

            if once:
                break
            else:
                # sleep x seconds
                self.LOG.debug("sleeping for {!r} seconds..."
                .format(self.update_interval()))
                sleep(self.update_interval())


    def start(self, once=False):
        """ Main function for app_loader.py """

        # this is to give ppp0 time to come up.
        STARTUP_DELAY = 60

        self.LOG.debug("Delaying start {!r} seconds or until network "
        "connection is established.".format(STARTUP_DELAY))

        for i in range(0, STARTUP_DELAY):
            if self.G.network_connected():
                self.LOG.info("Network connection detected, starting main loop.")
                break
            else:
                self.LOG.debug("Slept {0} seconds...".format(i))
            sleep(1)

        self.G.activate()

        # send normal report on boot/restart
        self.G.exo_report(self.apps_report())
        self.loop(once)

