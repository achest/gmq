#!/usr/bin/env python

# pylint: disable=R0903,E0101,R0903,W0232,C1001,W0312

import os, subprocess, ConfigParser
import logging
from threading import Timer
from constants import EngineCfgSects, SUPERVISOR_APP_CONF_FILE

try:
    from constants import formatter, ROOT_LOGGER
except:
    from .constants import formatter, ROOT_LOGGER

import tarball

class SupervisorDefault:
    """ Enum for supervisor config file OPTIONS defaults. """
    Opts = {'command': 'command',
            # 'directory': '/usr/local/bin',
            'stdout_logfile': '/var/log',
            'redirect_stderr': 'true',
            'stdout_logfile_maxbytes': '200KB',
            'stdout_logfile_backups': '1',
           }

class Installer(object):
    """ Class for installing a single application either from an GatewayEngine base
        install, or from new content retrieved from vendor content area.

        For installing multiple applications, put this in a for-loop. """
    def __init__(self, path_to_app, engine_cfg): #, base_install=False):
        # if base_install:
        # 	self.sprvsr_conf_path = os.path.join('..', 'supervisor.d')
        # else:
        self.LOG = logging.getLogger(ROOT_LOGGER+'.instlr')
        self.LOG.propagate = True
        self.sprvsr_conf_path = os.path.join('/etc', 'supervisor', 'conf.d')
        self.app_name = None
        self.app_version = None
        self.path_to_app = path_to_app
        self.engine_cfg_path = engine_cfg
        self.code, self.stdout = (0, "Nothing")

    def dir_name_and_version(self):
        """ If we're installing from a directory, get the name and version from
            the directory name. """
        split = os.path.basename(self.path_to_app).split('.')
        self.app_name, self.app_version = split[0], split[1].replace('v', '')

    def exec_install_dot_sh(self):
        """ This function executes the new application's installer.

        Supported installers are 'install.sh' and 'setup.py' files.

        Any non-zero numeric return code indicates a problem with installing
        the application.

        Returns:
            * retval: a tuple of (errorcode, description)

        NUMERIC_CODES:
            8  - Please check to make sure the 'shebang' is present in install.sh.
            7  - Unused.
            6  - Unused.
            5  - Unused.
            4  - Unused.
            3  - Unused.

            2  - Starting installation, setting up environment for installation. Receiving
                 this error code indicates that something went wrong during the setup steps
                 during the installation.

            1  - Executing installer. Receiving this error code indicates that something
                 went wrong before the installation took place.

            0  - Installer returns this value to indicate successful script execution.
            -1 - Supported installer not found. Either 'install.sh' or 'setup.py' not found.
            -2 - Can't execute install.sh script. Execute permissions not set.
            -3 - Caught general exception during installer execution. See gwe log for details.
            -4 - Supported installer not found. Either 'install.sh' or 'setup.py' not found.
        """
        ErrorCodes = {
            'shebang': (8, "Please check to make sure the "
                            "'shebang' is present in install.sh."),
            'Unused7': (7, ""),
            'Unused6': (6, ""),
            'Unused5': (5, ""),
            'Unused4': (4, ""),
            'Unused3': (3, ""),
            'start': (2, "Starting installation, Something went wrong"
                        " during the setup steps."),
            'progress': (1, "Executing installer. Something went wrong"
                            " during installtion."),
             'success': (0, "Successful script execution."),
            'no_install_shell': (-1, "Either 'install.sh' or 'setup.py' "
                                    "not found."),
            'no_execute_permission': (-2, "Execute permissions not set for"
                                        " install.sh script"),
            'general_exception': (-3, "General exception during installer"
                                    " execution, See gwe log for details."),
            'invalid_file': (-4, "Application path is not a "
                                "directory or a tarfile.")
            }

        self.LOG.debug("Starting install...")
        retval = ErrorCodes['start']
        start_dir = os.path.abspath(os.path.curdir)
        self.LOG.debug("Changing directory to application path: {!r}".format(self.path_to_app))
        os.chdir(self.path_to_app)
        cur_dir = os.path.abspath(os.path.curdir)
        self.LOG.debug("Current directory: {0}".format( cur_dir ))
        self.LOG.debug("Directory contents: {0}".format(os.listdir(cur_dir)))

        cmd = None
        # first, see if there's a setup.py
        if os.path.exists('./setup.py'):
            cmd = ['python', 'setup.py', 'install']
        # then, if there's also an install.sh, honor that over
        # the setup.py. That way if someone took the time to
        # write a GWE install script we will use it.
        if os.path.exists('./install.sh'):
            cmd = ['./install.sh']
        try:
            if cmd == None:
                retval = ErrorCodes['no_install_shell']
            elif os.path.exists(cmd[0]) or os.path.exists(cmd[1]):
                if cmd[0] == './install.sh' and not os.access(cmd[0], os.X_OK):
                    retval = ErrorCodes['no_execute_permission']
                else:
                    self.LOG.debug("Executing: {0}".format(cmd))
                    retval = ErrorCodes['progress']
                    try:
                        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, \
                                                    stderr=subprocess.STDOUT)
                        # hard-coded installer timeout kill of 20 minutes
                        timer = Timer(60*20, process.kill, [process])
                        self.LOG.debug("Installer running...")
                        timer.start()
                        stdout = ''
                        while True:
                            line = process.stdout.readline()
                            self.LOG.debug("Captured output from {!r}: {!r}".format(cmd, line))
                            stdout += line
                            if '' == line and process.poll() != None:
                                break
                        process.wait()
                        timer.cancel()
                        retval = (process.returncode, stdout)
                    except OSError as err:
                        if err.errno == 8:
                            self.LOG.debug(str(err))
                            retval = ErrorCodes['shebang']
                    except Exception as err:
                        self.LOG.debug("Caught Exception: {!r}".format(err))
                        retval = ErrorCodes['general_exception']
            else:
                self.LOG.debug("{!r} does not exist!.".format(cmd))
                retval = ErrorCodes['no_install_shell']
        finally:
            self.LOG.debug("Changing directory back to where we started: {!r}".format(start_dir))
            os.chdir(start_dir)
        return retval

    def create_supervisord_conf_file(self, app_path, app_name):
        """ With a the path to the newly extracted app and its name as inputs,
            create the supervisor.d conf file from the sections within. """
        retval = False
        self.LOG.debug("app_path: "+str(app_path))
        self.LOG.debug("app_name: "+str(app_name))
        gwe_config_path = os.path.abspath(os.path.join(app_path, SUPERVISOR_APP_CONF_FILE))
        if not os.path.exists(gwe_config_path):
            self.LOG.warning(
                """File {0} not provided, skipping supervisord configuration for app."""
                .format(gwe_config_path))
            retval = False
        else:
            self.LOG.debug("gwe_config_path: "+str(gwe_config_path))
            gwe_cfg_parser = ConfigParser.RawConfigParser(allow_no_value=True)
            gwe_cfg_parser.read(gwe_config_path)
            sprvsrd_cfg_parser = ConfigParser.RawConfigParser(allow_no_value=True)
            self.LOG.debug(SUPERVISOR_APP_CONF_FILE+" sections: "+str(gwe_cfg_parser.sections()))
            if gwe_cfg_parser.has_section('supervisord'):
                retval = True
                pgm_section = 'program:'+app_name
                sprvsrd_cfg_parser.add_section(pgm_section)
                for option in gwe_cfg_parser.options('supervisord'):
                    opt_val = gwe_cfg_parser.get('supervisord', option)
                    sprvsrd_cfg_parser.set(pgm_section, option, opt_val)
                    self.LOG.debug("Added {!r} = {!r} to [{!r}] supervisor config".format(
                        option, opt_val, pgm_section.replace("'", "")))

                # now, compare new sprvsrd_cfg against defaults
                for option in SupervisorDefault.Opts.keys():
                    if not sprvsrd_cfg_parser.has_option(pgm_section, option):
                        # StdOutLogFile must be dynamically created...
                        if option == 'stdout_logfile':
                            logfile = os.path.join(SupervisorDefault.Opts[option], app_name+'.log')
                            sprvsrd_cfg_parser.set(pgm_section, option, logfile)
                            self.LOG.debug("Added default {!r} = {!r} to [{!r}] supervisor config".format(
                                option,
                                logfile,
                                pgm_section.replace("'", "")))
                        else:
                            sprvsrd_cfg_parser.set(pgm_section, option, SupervisorDefault.Opts[option])
                            self.LOG.debug("Added default {!r} = {!r} to [{!r}] supervisor config".format(
                                option,
                                SupervisorDefault.Opts[option],
                                pgm_section.replace("'", "")))

                conf_file = os.path.join(self.sprvsr_conf_path, app_name+'.conf')
                if os.path.exists(self.sprvsr_conf_path):
                    with open(conf_file, 'wb') as cfg:
                        sprvsrd_cfg_parser.write(cfg)
                    self.LOG.debug("Successfully created supervisor conf file: {!r}".format(conf_file))
                else:
                    self.LOG.critical("""Supervisor conf path {} doesn't exist.
Unable to create supervisor conf file.""".format(self.sprvsr_conf_path))
            else:
                self.LOG.error("""Improperly formatted {} file.
Cannot create supervisor conf file.""".format(SUPERVISOR_APP_CONF_FILE))
                retval = False
        return retval

    def update_engine_config(self):
        """ Add new application name and version to Engine.config. """
        retval = False
        cfg_parser = ConfigParser.RawConfigParser(allow_no_value=True)
        self.LOG.debug("Trying to update {!r}".format(self.engine_cfg_path))
        if os.path.exists(self.engine_cfg_path):
            cfg_parser.read(self.engine_cfg_path)
            self.LOG.debug("Checking for [{!r}] section.".format(EngineCfgSects.Apps))
            if cfg_parser.has_section(EngineCfgSects.Apps):
                cfg_parser.set(EngineCfgSects.Apps, self.app_name, self.app_version)
                self.LOG.debug("Updated cfg with: {}: {}".format(self.app_name, self.app_version))
                retval = True
            else:
                self.LOG.debug("Unable to dump: '{!r}' '{!r}' '{!r}'".format(
                    EngineCfgSects.Apps, self.app_name, self.app_version))
                retval = False
            with open(self.engine_cfg_path, 'wb') as cfg:
                cfg_parser.write(cfg)
        else:
            self.LOG.critical("{!r} doesn't exist!".format(self.engine_cfg_path))
            retval = False
        return retval

    def install(self):
        """ Run installation steps for new app.
            New app can be a directory (usually a base install),
            or a tarball (usually installing from OneP. """
        self.code = 0
        self.stdout = 'SUCCESS!'
        tar = tarball.ExistingTarball(self.path_to_app)
        if tar.is_tarball():
            self.LOG.debug("Installing from tarball...")
            self.path_to_app = tar.extract()
            self.app_name = tar.name
            self.app_version = tar.version.replace('v', '')
            self.code, self.stdout = self.exec_install_dot_sh()
            if not self.code == 0:
                self.LOG.error("Something went wrong when executing install.sh script.")
                self.LOG.error("code {!r}: message: {!r}".format(self.code, self.stdout))
                return
            if not self.create_supervisord_conf_file(tar.extract_location, tar.name):
                self.LOG.debug("Couldn't create supervisor .conf file. Exiting installer.")
                return
            if not self.update_engine_config():
                self.LOG.debug("Couldn't update Engine.config file. Exiting installer.")
                return
        elif os.path.isdir(self.path_to_app):
            self.LOG.debug("Installing from directory: {!r}".format(self.path_to_app))
            self.dir_name_and_version()
            self.code, self.stdout = self.exec_install_dot_sh()
            if not self.code == 0:
                self.LOG.debug("Something went wrong when executing install.sh script.")
                self.LOG.debug("code {!r}: message: {!r}".format(self.code, self.stdout))
                return
            if not self.create_supervisord_conf_file(self.path_to_app, self.app_name):
                self.LOG.debug("Couldn't create supervisor .conf file. Exiting installer.")
                return
            if not self.update_engine_config():
                self.LOG.debug("Couldn't update Engine.config file. Exiting installer.")
                return
        else:
            self.code, self.stdout = (-1, "{!r} is not a directory or a tarfile.".format(
                self.path_to_app))
            return


def main():

    import os, sys

    debug_level = logging.DEBUG if False else logging.INFO
    LOG = logging.getLogger(ROOT_LOGGER)
    LOG.setLevel(debug_level)
    streamh = logging.StreamHandler(sys.stdout)
    streamh.setFormatter(formatter)
    LOG.addHandler(streamh)
    LOG.propagate = True

    LOG.debug("Installing app(s): {!r}".format(sys.argv[1:]))

    for app in sys.argv[1:]:
        gwe_dir = os.path.abspath(os.path.dirname(__file__))
        engine_cfg_path = os.path.join(gwe_dir, 'Engine.config')
        instlr = Installer(app, engine_cfg=engine_cfg_path) #, base_install=True)
        instlr.install()
        if instlr.code == 0:
            LOG.debug("{!r}: {!r}".format(app, instlr.stdout))
            LOG.info("Installing app {!r} succeeded.".format(app))
        else:
            LOG.error("Installation of app {!r} FAILED: code: {!r}".format(app, instlr.code))
            LOG.error("{}".format(instlr.stdout))


if __name__ == '__main__':
    main()
