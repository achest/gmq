""" Module for handling tarfile operations. """
# pylint: disable=W0312
import os, tarfile, json
from sys import stderr
from shutil import rmtree
from utils import isFileNameValid
import logging
from os import access, X_OK

try:
    from constants import ROOT_LOGGER
except:
    from .constants import ROOT_LOGGER

class Tarball(object):
    """ Class containing methods and variables for dealing with
        tarfiles. """
    def __init__(self, path):
        self.LOG = logging.getLogger(ROOT_LOGGER+'.tball')
        self.LOG.propagate = True
        self.name = None
        self.version = None
        self.path = path
        if os.name == "nt":
            import random, string
            # If we're on Windows randomize to some local dir,  That way we can clean up later if
            # need be and not worry about stomping on something else
            self.extract_path = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
        else:
            self.extract_path = '/tmp'
        self.extract_location = None

    @staticmethod
    def parse_filename(basename):
        """Verifies if a given filename satisfy <app_name>.v<#>.tar.gz format"""
        LOG = logging.getLogger(ROOT_LOGGER+'.tball')
        result, app_name, app_version = False, '', ''
        if not isFileNameValid(basename):
            LOG.critical("{0} is an invalid filename.".format(basename))
        else:
            LOG.debug("{0} is a valid name format".format(basename))
            name_split = basename.split('.')
            # good name format for tarball is defined by <app_name>.v<#>.tar.gz
            parse_stage1, parse_stage2, parse_stage3 = False, False, False
            # Check for name length and extension criteria
            suffix = ''.join(name_split[-2:])
            parse_stage1 = len(name_split) >= 4 and suffix == 'targz'
            if parse_stage1:
                # Check if app_name and app_version fields are not empty
                name_tmp = name_split[0]
                version_tmp = ''.join(name_split[1:-2])
                parse_stage2 = name_tmp != '' and version_tmp != ''
                if parse_stage2:
                    # Check if version field starts with 'v' and  has min one more character
                    parse_stage3 = name_split[1][0] == 'v' and len(name_split[1]) >= 2
            else:
                LOG.critical("Name either has too few elements or suffix not '.tar.gz'.")
            # final result is output of above 3 stage parsing
            result = parse_stage1 and parse_stage2 and parse_stage3
            if result:
                app_name = name_split[0]
                 # throw away the 'v' character on the beginning of string
                app_version = '.'.join(name_split[1:-2])[1:]
            else:
                LOG.critical(
                    "{0} is not in required name format: <app_name>.v<#>.tar.gz"
                    .format(basename)
                )
        return result, app_name, app_version

    def open(self, tarball):
        """
            Wrapper function for tarfile.open().

            If tarball is not readable, return None.
        """
        fd = None
        try:
            fd = tarfile.open(tarball)
        except tarfile.ReadError as exc:
            self.LOG.critical("Cannot open tarball: {}".format(exc))
        return fd

    def getmember(self, member):
        """
            If member exists in tarball, return a file-like object
            representing the member.
        """
        tball = self.open(self.path)
        try:
            return tball.getmember(member)
        except KeyError:
            return None

    def getfile(self,file):
        tball = self.open(self.path)
        return tball.extractfile(file)

    def has_install_dot_sh(self):
        """ Returns a boolean for determining if the tarball
        contains an 'install.sh' script. """
        return self.getmember('install.sh')


    def install_dot_sh_executable(self):
        """ Returns a boolean for determining if the 'install.sh'
        script has the 'x' flag set.    """
        from os import X_OK
        try:
            the_file = self.getmember('install.sh')
            return 1 == the_file.mode & X_OK
        except IndexError:
            return False
        except AttributeError:
            return False

    def is_tarball(self):
        """ Determines if a given file is a properly formatted tarball. """
        basename = os.path.basename(self.path)
        self.LOG.debug("Here's the given tarball name: {!r}".format(basename))
        retval = False
        if os.path.exists(self.path):
            if os.path.isdir(self.path):
                self.LOG.debug("{!r} is a directory, not a tarfile.".format(self.path))
                retval = False
            else:
                try:
                    name_format_is_good, app_name, app_version = Tarball.parse_filename(basename)
                    if tarfile.is_tarfile(self.path) and name_format_is_good:
                        self.LOG.debug("File {!r} is a valid tarfile.".format(self.path))
                        retval = True
                    elif not name_format_is_good and tarfile.is_tarfile(self.path):
                        self.LOG.debug("Filename not in 'NAME.vVERSION.tar.gz' format. \
                            Disregarding file: {!r}".format(self.path))
                        retval = False
                    elif name_format_is_good and not tarfile.is_tarfile(self.path):
                        self.LOG.debug("Filename {!r} is in 'NAME.vVERSION.tar.gz' format, \
                            but not a tarball".format(
                            self.path))
                        retval = False
                    else:
                        self.LOG.error("File {!r} is not eligible for installation.".format(
                        	self.path))
                        retval = False
                except IOError as err:
                    if err.errno == 21:
                        self.LOG.debug("System says {!r} is a directory.".format(self.path))
                        retval = False
        else:
            self.LOG.debug("File {!r} does not exist!".format(self.path))
            retval = False
        return retval

    def get_name_and_version(self):
        """ Populates self.name and self.version based on self.path. """
        basename = os.path.basename(self.path)
        self.result, self.name, self.version = Tarball.parse_filename(basename)
        if self.result == True:
            self.LOG.debug("App name is {!r}".format(self.name))
            self.LOG.debug("App Version is {!r}".format(self.version))
            self.extract_location = os.path.join(self.extract_path, self.name+'.'+'v'+self.version)
        else:
            self.LOG.debug("{0} is not in required name format: <app_name>.v<#>.tar.gz".format(basename))

    def extract(self):
        """ Extract a tarball and return the path to its extract directory.
        """
        self.LOG.debug("Extracting {!r} to {!r}".format(
            self.path, os.path.abspath(self.extract_path)))

        basename = os.path.basename(self.path)
        basename = basename.replace('.tar.gz', '')
        extract_location_will_be = os.path.join(self.extract_path, basename)
        if os.path.isdir(extract_location_will_be):
            self.LOG.info("Moving this out of the way because it has the same name: {!r}".format(
                extract_location_will_be))
            rmtree(extract_location_will_be)

        tar = tarfile.open(self.path)
        tar.extractall(extract_location_will_be)
        self.LOG.debug("Contents of unpacked tarball:")
        self.LOG.debug(os.listdir(extract_location_will_be))
        tar.close()
        self.extract_location = extract_location_will_be
        return self.extract_location

    def remove(self):
        """ Get rid of the tarball. """
        self.LOG.debug("Removing tarball {!r}".format(self.path))
        os.remove(self.path)

    def remove_install_package(self):
        """ Method that removes the install package (i.e. the contents
            of the extracted tarball) from its temporary location. """
        self.LOG.info("Removing install package: {!r}".format(self.extract_location))
        if os.name == 'nt':
            # remove the random directory name too
            rmtree(self.extract_path)
        else:
            rmtree(self.extract_location)

class SectionMissing(Exception):
    pass

class SectionInvalid(Exception):
    pass

class Namespace(object):
    """
        This is a helper class that allows '.' access to
        dictionary members instead of dict['member'] notation.
    """
    def __init__(self, **kw):
        self.__dict__.update(kw)
        org_dict = {
            'name': unicode,
            'version': unicode,
            'includes': list,
            'excludes': list,
            'pre_build_cmds': list,
            'post_build_cmds': list
        }
        for org in org_dict:
            if kw.get("verbose"):
                logger = logging.getLogger(ROOT_LOGGER+'.tball')
                # logger.propagate = True
                logger.debug("Checking for section: {}".format(org))
            if org in kw:
                pass
            else:
                raise SectionMissing("{!r} section is not found in json input file!".format(org))
            if not isinstance(kw.get(org), org_dict[org]):
                raise SectionInvalid("{!r} section has {!r} for {!r}, should be {!r}".format(
                    org, type(org), self.__dict__[org], org_dict[org]))


class NewTarball(Tarball):
    """ Class for creating new tarfiles. """
    def __init__(self, tarball_fname, response):
        Tarball.__init__(self, tarball_fname)
        self.tarball_fname = tarball_fname
        self.response = response

    def create_tarball_from_download(self):
        """ Inputs:
                None
            Output:
                * 'self.extract_path<app.vN.tar.gz>'
        """
        tarball = os.path.join(self.extract_path, self.tarball_fname)
        with open(tarball, 'wb+') as f:
            for chunk in self.response.iter_content():
                f.write(chunk)
        self.path = tarball
        self.get_name_and_version()
        self.LOG.debug("Created tarball: {}".format(self.path))

    def create_tarball_from_build_file(self):
        """ Inputs:
                * self.tarball_fname:   is not used directy. It is overridden
                                        by the desired tarball name defined
                                        by JSON input file in self.response.
                * self.response:        is the path to a json file that defines
                                        a valid gwe app tarball we can create.
            Output:
                * '/pwd/<app.vN.tar.gz>'
        """

        with open(os.path.abspath(self.response)) as jsf:
            conf = Namespace(**json.load(jsf))

        # pre build command execute
        for cmd in conf.pre_build_cmds: # pylint: disable=I0011,E1101
            self.LOG.debug("Executing pre_build_cmd: {}".format(cmd))
            os.system(cmd)
        self.tarball_fname = '{}.v{}.tar.gz'.format(conf.name, conf.version) # pylint: disable=I0011,E1101
        if not self.parse_filename(self.tarball_fname)[0]:
            self.LOG.critical(
                "Cannot create valid tarball from name '{}' and version '{}'"
                .format(conf.name, conf.version) # pylint: disable=I0011,E1101
            )
            return False
        tarball_path = os.path.join(os.getcwd(), self.tarball_fname)
        # tarfile create
        with tarfile.open(tarball_path, 'w:gz') as tFile:
            files_to_add = list(set(conf.includes)-set(conf.excludes)) # pylint: disable=I0011,E1101
            for include in files_to_add:
                self.LOG.debug("a {}".format(include))
                tFile.add(include)
        self.path = tarball_path
        # post build command execute
        for cmd in conf.post_build_cmds: # pylint: disable=I0011,E1101
            self.LOG.debug("Executing post_build_cmd: {}".format(cmd))
            os.system(cmd)
        return True

class ExistingTarball(Tarball):
    """ Class for dealing with existing tarfiles. """
    def __init__(self, path):
        Tarball.__init__(self, path)
        self.get_name_and_version()







