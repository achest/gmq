#!/usr/bin/env python
"""
    Utility functions for GatewayEngine.
"""
# pylint: disable=W0312
import textwrap, ntpath
from ConfigParser import RawConfigParser

class colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

wrap=textwrap.TextWrapper(
    initial_indent=colors.FAIL+' >        '+colors.ENDC,
    subsequent_indent=colors.FAIL+' >        '+colors.ENDC,
    width=50
)

GWE_PLUGIN_REQUIREMENTS = {
    'install_sh_exists': {
        'success': False,
        'help': wrap.fill('''There is no "install.sh" present in the tarball.''')
    },
    'install_sh_mode': {
        'success': False,
        'help': wrap.fill('''The "install.sh" script does not have the `x` bit set.''')
    },
    'is_valid_filename': {
        'success': False,
        'help': wrap.fill('''The filename for the tarball is invalid.''')
    },
    'is_tarball': {
        'success': False,
        'help': wrap.fill('''The app is not in a gzipped tar format.''')
    },
    'shebang_present_at_start_of_install_sh_file': {
        'success': False,
        'help': wrap.fill('''The "install.sh" file doesn\'t have the "#!/bin/sh" shebang on the first line.''')
    },
    'no_crnl_in_install_sh': {
        'success': False,
        'help': wrap.fill('''The "install.sh" contains Windows-style (illegal) line endings "\\r\\n".''')
    },
    'supervisor_conf_file_included': {
        'success': False,
        'help': wrap.fill('''The tarball does not contain a "supervisor.conf" file. This in only a requirement for long-running apps that need to be restarted.''')
    },
    'has_supervisord_section': {
        'success': False,
        'help': wrap.fill('''The "supervisor.conf" file has no [supervisord] section.''')
    },
    'supervisord_section_has_options': {
        'success': False,
        'help': wrap.fill('''WARNING: Your "supervisor.conf" file has a [supervisord] section, but no options. Defaults will be used.s''')
    }
}

TEST = False
GWE_BUILD = 'gwe.build' if not TEST else 'gwe.test'

def conf_dir():
    from os import path
    return path.dirname(path.abspath(__file__))

def gwe_conf():
    from os import path
    return path.join(conf_dir(), 'Gateway.cfg')

def engine_conf():
    from os import path
    return path.join(conf_dir(), 'Engine.config')


def gwe_cik():
    try:
        from AtomicConfigParser import AtomicConfigParser as Parser
    except:
        from ConfigParser import RawConfigParser as Parser
    p = Parser()
    cfg_file = gwe_conf()
    p.read(cfg_file)
    return p.get('device', 'cik')


def display_test_results(test_results):
    for testname, results in test_results.iteritems():
        if results['success']:
            print('[{0}] -- {1}'.format(colors.OKGREEN+'PASS'+colors.ENDC, testname))
        else:
            print('[{0}] -- {1}\n\n{2}\n'.format(colors.FAIL+'FAIL'+colors.ENDC, testname, results['help']))

def isFileNameValid(fileName):
    '''
    checks that a file meets the required format of myapp.v1.tar.gz
    regex ".+\.v\d+\.tar\.gz"

    Returns False if there is any whitespace in the tarball name.
    '''
    import re
    # check for whitespace
    if re.match(r'[\s]+', fileName):
        return False
    # check naming convention
    return re.match(r'[^ ]+\.v[^ ]+\.tar\.gz', fileName)

def check_build_file(path_to_json_file, verbose=False):
    from tarball import Namespace, SectionInvalid, SectionMissing
    from os import path as ospath
    import json
    try:
        with open(path_to_json_file, 'r') as jsf:
            json.load(jsf)
    except:
        return colors.FAIL+"[FAIL]"+colors.ENDC+" - Cannot load JSON."
    with open(ospath.abspath(path_to_json_file), 'r') as jsf:
        try:
            conf = Namespace(verbose=verbose, **json.load(jsf))
        except SectionMissing as exc:
            return colors.FAIL+"[FAIL]"+colors.ENDC + " - {}".format(exc)
        except SectionInvalid as exc:
            return colors.FAIL+"[FAIL]"+colors.ENDC + " - {}".format(exc)

    return colors.OKGREEN+"[PASS]"+colors.ENDC

def check_tarball(full_path_of_tarball, cleanup=False, verbose=False, show_results = True, cleanup_tmp = False):
    '''
    cleanup_tmp only removes the dir used to extract the file for testing
    '''
    from tarball import Tarball
    import os, stat
    test_results = GWE_PLUGIN_REQUIREMENTS
    if verbose:
        print full_path_of_tarball
    t = Tarball(full_path_of_tarball)
    if not verbose:
        # turn off the logger
        t.LOG.disabled = True

    test_results['is_valid_filename']['success'] = isFileNameValid(ntpath.basename(full_path_of_tarball))
    if not test_results['is_valid_filename']:
        # If we don't have a valid file name, no sense running the rest of the tests.
        if show_results:
            print("File name is invalid for installer.  Aborting remaining tests")
            display_test_results(test_results)
        return test_results

    t.get_name_and_version()

    #### Check if it's a valid tarball ####
    test_results['is_tarball']['success'] = t.is_tarball()

    if not test_results['is_tarball']['success']:
        # If we don't have a valid tarball, no sense running the rest of the tests.
        if show_results:
            print("No Valid Tarball.  Aborting remaining tests.")
            display_test_results(test_results)
        return test_results

    # test that a install.sh exists
    if t.has_install_dot_sh():
        test_results['install_sh_exists']['success'] = True
    else:
        test_results['install_sh_exists']['success'] = False

    if t.install_dot_sh_executable():
        test_results['install_sh_mode']['success'] = True
    else:
        test_results['install_sh_mode']['success'] = False

    if test_results['install_sh_exists']['success']:
        #Check for Shebang
        file_ = t.getfile('install.sh')
        sequence = file_.readline(2)
        if sequence == '#!':
            test_results['shebang_present_at_start_of_install_sh_file']['success'] = True
        else:
            test_results['shebang_present_at_start_of_install_sh_file']['success'] = False
        file_ = t.getfile('install.sh')
        value = file_.read()

        i = value.find('\r\n')
        if i == -1:
            test_results['no_crnl_in_install_sh']['success'] = True
        else:
            test_results['no_crnl_in_install_sh']['success'] = False
    else:
        if show_results:
            print("No install.sh file exists, skipping tests that require it.")

    #Check for supervisord section
    if t.getmember('supervisor.conf'):
        test_results['supervisor_conf_file_included']['success'] = True

        parser = RawConfigParser()
        parser.readfp(t.getfile('supervisor.conf'))

        if parser.has_section('supervisord'):
            test_results['has_supervisord_section']['success'] = True
            section_option = len(parser.options('supervisord'))
            if section_option >= 1:
                test_results['supervisord_section_has_options']['success'] = True
            else:
                test_results['supervisord_section_has_options']['success'] = False
        else:
            test_results['has_supervisord_section']['success'] = False
    else:
        test_results['supervisor_conf_file_included']['success'] = False

    if cleanup:
        t.remove()
    if cleanup_tmp:
        t.remove_install_package()

    if show_results:
        display_test_results(test_results)

    return test_results


def create_build_file(**kwargs):
    """
        Call this function with kwargs to avoid interactive mode.
        This function helps you create a gwe.build file for a Custom Gateway Application.
    """
    from os import path
    import json

    build_file = \
        path.join(path.abspath(path.curdir), kwargs['build_file']) \
        if kwargs.get('build_file') \
        else path.join(
            path.abspath(path.curdir),
            raw_input("Provide build file name (my_app.json): ")
        )

    app_name = \
        kwargs['app_name'] \
        if kwargs.get('app_name') \
        else raw_input("Provide app name (my_app): ")
    app_version = \
        kwargs['app_version'] \
        if kwargs.get('app_version') \
        else raw_input("Provide app version (1): ")

    build_dict = {
        "name": app_name,
        "version": app_version,
        "includes": [
            "install.sh",
        ],
        "excludes": [],
        "pre_build_cmds": [],
        "post_build_cmds": []
    }

    with open(build_file, 'wb') as bfj:
        bfj.write(json.dumps(build_dict, indent=2))

    print """==================================================
==============  Build file created  ==============
==================================================

A bare-bones JSON build file has been created. It
supports the following parameters:

 "name"             -   This is the name Gateway
                        Engine will use as your
                        application's name.

 "version"          -   This is the version of
                        your application. Any
                        time you edit the code
                        or anything in your
                        application, you should
                        increment or otherwise
                        change the version.

 "includes"         -   This is a list of files
                        that you want to include
                        in your application
                        tarball. Add files to
                        this list to suit the
                        needs of your applicaiton.

 "excludes"         -   This is a list of files
                        that you don't want in
                        your application tarball.
                        This option is often used
                        when specifying "include"
                        lists with globs like "*".

 "pre_build_cmds"   -   This is a list of system
                        commands you want to run
                        before the tarball is
                        created. Common uses for
                        this feature are to do
                        "wget" to fetch resources
                        on the internet that you
                        want included in your
                        application tarball.

 "post_build_cmds"  -   This is a list of system
                        commands you want run
                        after the tarball is
                        created. This is handy
                        for cleaning up build
                        artifacts after the
                        build completes.

For more information on Gateway Engine
please visit:

    docs.exosite.com/exositeready/gwe

Build file location:

    {0}

==================================================
============  gwesupport@exosite.com  ============
==================================================
""".format(build_file)



