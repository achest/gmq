# Gateway Engine Configuration
Welcome to the configuration section of the Gateway Engine application by Exosite.
In order to get up and running, the two files that need to be configured are:
 - Engine.config
 - Gateway.cfg
## Engine.config
This file contains two configuration variables that you can use to customize GatewayEngine's run-time environment:
 1. `update_interval`
 2. `user_agent`
### `update_interval`
The default amount of time, in seconds, between Gateway Engine's check-ins.
On startup, Gateway Engine will immediately check for new applications to download and install in the `app_loader_fetch` dataport. It also checks for changes made to `update_interval` and change this default accordingly.
### `user_agent`
It is often useful in web applications to specify a customer `User-Agent` header to http requests. Use this configuration setting to distinguish your application from others that may be using Gateway Engine if so desired, but it is not necessary.
## Gateway.cfg
This file contains the information needed for communication with Exosite's OnePlatform:
 1. `cik`
 2. `model`
 3. `vendor`
 4. `uuid`
### `cik`
The `cik` configuration option is almost never set by you (the developer). This configuration option is included as a blank entry for two reasons:
 1. To inform you (the developer) where Gateway Engine's `cik` is stored on the filesystem.
 2. To allow for the rare case of telling Gateway Engine what it's `cik` is instead of it having to retrieve it from Exosite during the normal Provisioning process.
The normal case is to leave this blank to allow Gateway Engine to use the Exosite Provisioning API to retrieve its `cik` and store it in `Gateway.cfg`.
### `model`
This is the Device Model needed by Exosite Provisioning API requests. The current convention is to name the Device Model as `<vendor>_gwe_v1`, but what you choose to call the GatewayEngine's Device Model should be the same name as the Device Model name used in the `exo spec` exoline command when you create your Gateway Engine CLONE device in Exosite's OnePlatform.
### `vendor`
This, often-times is your company name, but it must be the same as the Vendor name you chose when you created your whitelabel domain with Exosite. It is used in Exosite Provisioning API requests.
### `uuid`
This is the serial number of the device running Gateway Engine software. The default `NO MAC FOUND` is meant to be invalid and changed by you. This serial number is the serial number you want Gateway Engine to use when it provisions itself and retrieves its `cik`. 