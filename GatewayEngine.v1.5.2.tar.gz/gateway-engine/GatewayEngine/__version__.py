MAJOR_VERSION = '1'
MINOR_VERSION = '5'

__version__ = MAJOR_VERSION+'.'+MINOR_VERSION
__version__ = __version__+'.2'
