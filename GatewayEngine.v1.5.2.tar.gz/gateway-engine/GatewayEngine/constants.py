"""
    Separate some logging attributes for global imports.
"""
import os
from logging import Formatter

ROOT_LOGGER = 'GWE'

form = '%(asctime)s-%(levelname)s-%(name)s:%(funcName)s:%(lineno)d ::> %(message)s'
formatter = Formatter(form)

SUPERVISOR_APP_CONF_FILE = 'supervisor.conf'

DEFAULT_ENGINE_CONF_FILE = os.path.join(
    os.path.abspath(os.path.dirname(__file__)),
    'Engine.config'
)
DEFAULT_GATEWAY_CONF_FILE = os.path.join(
    os.path.abspath(os.path.dirname(__file__)),
    'Gateway.cfg'
)

class EngineCfgSects:
    """ Enum for cfg file sections. """
    Apps = 'apps'
    Device = 'device'

class EngineCfgOpts:
    """ Enum for cfg file options """
    UpdateInterval = 'update_interval'
    UserAgent = 'user_agent'

class GatewayCfgSects:
    """ Enum for cfg file sections. """
    Dataports = 'dataports'

class GatewayCfgOpts:
    """ Enum for cfg file options """
    UsageReport = 'usage_report'
    EngineReport = 'engine_report'
    EngineFetch = 'engine_fetch'
    DeviceInfo = 'device_info'
    FetchStatus = 'fetch_status'
    UpdateInterval = 'update_interval'

user_agent_prefix = 'GatewayEngine-v'
