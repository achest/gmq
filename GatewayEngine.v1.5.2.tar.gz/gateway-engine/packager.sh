#!/bin/bash -ex

# #############################################################################
# The packager.sh is a script intended to be run by CI tools like Jenkins. This
# script is designed to make the packaging of GWE + Custom Gateway Applications easier
# and distributable to gateway vendors for installation onto gateway hardware.
#
# This script is designed to be run from a Gateway Engine Custom Gateway Application 
# source directory where a gwe.build file exists. This script's working 
# directory starts at ENV variable WORKSPACE, if this is not set, it will run
# from PWD. 
#
# The script does the following in order:
#   -   The script assumes that a Gateway Engine Release tarball 
#       has been extracted to the Custom Gateway Application source directory.
#       To run this script: ./gwe/packager.sh
#   -   Create the Custom Gateway Application build from its gwe.build file.
#   -   Move resultant Custom Gateway Application tarball into the 
#       gateway-engine/apps_to_install directory.
#   -   Create the Gateway.cfg file from gateway-conf function 
#       in the Custom Gateway Application's gwe.build file and move it
#       to the ./gateway-engine/init/ directory.
#   -   Create ./tmp directory, clone all repos specified in 
#       apps_to_install function in the Custom Gateway Application gwe.build
#       file and move them to the ./gateway-engine/apps_to_install/
#       directory. This is how some Gateway Engine users get other
#       dependencies their user application might have to be installed
#       by Gateway Engine during installation.
#   -   Remove/cleanup the ./tmp directory.
#   -   Create a BUILD_ID based on the Custom Gateway Application's current
#       git hash and the build_id function in its gwe.build file.
#   -   Replace the GatewayEngine/Gateway.cfg file with the output
#       from the gateway-cfg function in the Custom Gateway Application 
#       function.
#   -   Generate the pre_ and post_ install_commands.sh scripts
#       and move them to the GatewayEngine/init/ directory.
#   -   Execute the gwe_build function from the 
#       ./gateway-engine/gwe.build file, finilizing the build and
#       creating a Custom Gateway Application Release tarball. The tarball 
#       name is written the a file called release_id.txt. 

# #############################################################################

# versions matter with various cli options
tar --version

echo "Creating Custom Gateway Application release..."
if [ -n "$WORKSPACE" ] ; then
    WS=$WORKSPACE
else
    WS=$PWD
fi
GWE=$WS/gateway-engine
TMP=$GWE/tmp
APPS=$GWE/apps_to_install
INIT=$GWE/init

# package the application and put it into apps_to_install
cp "$(source ${WS}/gwe.build && gwe_build)" "$APPS"

# need a temp directory to do clones and checkouts of 
# apps in customer repo's gwe.build:apps_to_install file:function
mkdir -p "${TMP}"
cd "${TMP}"

# start collection tar excludes
OTAU_EXCLUDES="$(source ${WS}/gwe.build && release_tar_excludes)"

for line in `source ${WS}/gwe.build && apps_to_install`
do

    # ls -la
    APP=`echo $line | cut -d'=' -f1 | xargs` # xargs trims whitespace
    rm -rf ${APP} # move any old versions out of the way.
    GIT_INFO=`echo $line | cut -d'=' -f2`
    REPO=`echo ${GIT_INFO} | cut -d',' -f1`
    BRANCH=`echo ${GIT_INFO} | cut -d',' -f2`
    echo "Packaging ${APP} from ${REPO}:${BRANCH} repo:branch."
    git clone ${REPO}
    cd ${APP}
    git checkout ${BRANCH}
    ls -la

    # This `mv` command is the magic point at which the `gwe.build` shell
    # file is sourced and the `gwe_build` function is executed. 

    # This part of the GWE release process makes it truly customizable
    # to your customer / custom application you want to bundle up
    # with your GWE build.

    # When writing the `gwe.build` source file, just make sure of 
    # two things
    # 1. the `gwe_build` function packages up either a directory or a tarball
    # that conforms to the GWE install requirements.
    # 2. the `gwe_build` function prints the full-path to that directory
    # or tarball so the caller (packager.sh. i.e. this file) can find it
    # and move it into the `apps_to_install` folder.
    mv $(source gwe.build && gwe_build) ${APPS}

    # if you don't need to set any excludes, that's fine
    # just make sure you have a function in gwe.build called
    # otau_tar_excludes and have it return 0 or something
    OTAU_EXCLUDES="${OTAU_EXCLUDES} $(source gwe.build && otau_tar_excludes)"
    cd "${TMP}"

done
cd ${WS}
rm -rf "${TMP}"

# # create BUILD_ID
# cd "${GWE}"
# GWE_GIT_HASH=`git describe --always` # TODO: why does this get the CGA git hash!!!!????

# BUILD_ID="${BUILD_NUMBER}"
cd ${WS}
APP_BUILD_ID=$(source gwe.build && build_id)

# NOTE: DISABLING THIS FEATURE. The reason for this is because this script
# is now being used to package multiple apps sequentially so it can 
# be called multiple times. This means that the last one to call
# packager.sh will win.
# # Get the Gateway Engine's Gateway.cfg configuration from the
# # Custom Gateway Application's gwe.build file and replace the existing one.
# # This step allows the Custom Gateway Application to customize the Gateway
# # Engine VENDOR, MODEL, UUID, IFACE, etc. variables.
# #
# # NOTE: Since this script is intended to package Custom Gateway Application
# # releases with Gateway Engine, the Custom Gateway Application gwe.build file
# # MUST specify a valid Gateway.cfg configuration in the gateway-cfg 
# # function.
# source ${WS}/gwe.build && gateway-cfg > ${GWE}/GatewayEngine/Gateway.cfg

# Generate and insert the Custom Gateway Application pre-install script 
source ${WS}/gwe.build && pre_install_commands >> ${INIT}/pre_install_commands.sh
# Generate and insert the Custom Gateway Application post-install script
source ${WS}/gwe.build && post_install_commands >> ${INIT}/post_install_commands.sh

# Finalize build
echo "Creating GWE tarball..."
cd ${GWE}
echo $PWD

RELEASE_TARBALL=`source gwe.build && basename $(gwe_build DONT_APPEND_BUILD_ID)`
# USER_APP_RELEASE_ID=${USER_APP_BUILD_ID}.tar.gz
# echo "export RELEASE_ID=${USER_APP_RELEASE_ID}" > ../release_id.env
# source release_id.env
cd ${WS}
mv ${GWE}/${RELEASE_TARBALL} ${RELEASE_ID}



