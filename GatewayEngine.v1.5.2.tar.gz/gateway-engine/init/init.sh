#!/bin/sh

set -x

######################################################
echo "Copying init scripts into /etc/init.d"

hash update-rc.d
if [ 0 -ne $? ] ; then
    echo "update-rc.d not found."

    # installing the init.d scripts this way works for
    # versions of linux that do not have update-rc.d installed
    # this is common on gateways like the 400AP which is just
    # a busy-box linux machine.
    INIT_D_FILES="S80ftdi S90supervisord"
    for f in $INIT_D_FILES
    do
        echo "Copying $f"
        cp $f /etc/init.d
        chmod o+x /etc/init.d/$f
    done
else
    # installing init.d scripts this way works from most debian
    # versions of linux. 
    INIT_D_FILES="S80ftdi supervisor"
    for f in $INIT_D_FILES
    do
        echo "Removing any old script: $f"
        update-rc.d -f $f remove
        rm -f /etc/init.d/$f
        echo "Copying $f"
        cp -f $f /etc/init.d
        chmod o+x /etc/init.d/$f
        update-rc.d $f defaults
    done
    # do a reload in case any previous versions were overwritten
    systemctl daemon-reload
fi

echo "Done installing configurations"
