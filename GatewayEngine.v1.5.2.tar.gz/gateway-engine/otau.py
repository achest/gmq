"""
    Module for executing config file migrations, upgrades and other
    tasks related to Over-The-Air-Updates of Gateway Engine.
"""
# pylint: disable=W0312

from __future__ import absolute_import
import os, sys, shutil
from shutil import copyfile

def upgradeConfigFile(config_file_to_upgrade):
    from ConfigParser import RawConfigParser as Parser
    p = Parser()
    p.read(config_file_to_upgrade)
    if not p.has_option('device', 'iface'):
        print("No 'iface' option detected. Setting to empty value.")
        p.set('device', 'iface', """''""")
        with open(config_file_to_upgrade, 'wb') as cfg:
            p.write(cfg)
    else:
        print("{}.{} option exists, not overriding.".format('device', 'iface'))

    if not p.has_section('dataports'):
        print("No 'dataports' section detected. Creating with default values.")
        p.add_section('dataports')
        p.set('dataports', 'usage_report', 'usage_report')
        p.set('dataports', 'engine_report', 'engine_report')
        p.set('dataports', 'engine_fetch', 'engine_fetch')
        p.set('dataports', 'device_info', 'device_info')
        p.set('dataports', 'fetch_status', 'fetch_status')
        p.set('dataports', 'update_interval', 'update_interval')
        with open(config_file_to_upgrade, 'wb') as cfg:
            p.write(cfg)
    else:
        print("{} section exists, not overriding.".format('dataports'))


def attemptUpgrade():
    """ If Gateway.cfg exists on current system, copy it into here
    so that we reinstall the same cfg. """

    print("Starting upgrade attempt.")
    # TODO: Once its proved that from __future__ import absolute_import
    # directive used is refering absolute path for gwe installtion, below
    # commented code can be removed.
    # in order to get the path of pre-existing GatewayEngine install,
    # the current directory must be removed from sys.path so that
    # the 'import' of GatewayEngine won't use the one from the current
    # directory
    path_to_remove = os.path.abspath(os.path.curdir)
    sys.path.remove(path_to_remove)

    # this should import from a previous installation
    try:
        from GatewayEngine.utils import gwe_conf
        config_dir_name = 'GatewayEngine'
        config_file_name = 'Gateway.cfg'

        new_cfg_path = os.path.abspath( os.path.join(config_dir_name, config_file_name ))
        existing_gateway_cfg_file = gwe_conf()
        # If there is an existing Gateway.cfg file
        if os.path.isfile(existing_gateway_cfg_file):
            print("Migrating an existing config file from {!r} to {!r}".format(
                existing_gateway_cfg_file, new_cfg_path))
            try:
                copyfile(existing_gateway_cfg_file, new_cfg_path)
            except shutil.Error as e:
                print('Error: %s' % e)
            upgradeConfigFile(new_cfg_path)
        else:
            print("No config migration required.")

        config_file_name = 'Engine.config'
        new_cfg_path = os.path.abspath( os.path.join(config_dir_name, config_file_name ))
        existing_gateway_cfg_file = gwe_conf()
        # now point the path at the Engine.config file instead of the Gateway.cfg
        head, _ = os.path.split(existing_gateway_cfg_file)
        existing_engine_config_file = os.path.join(head, config_file_name)
        # If there is an existing Engine.config file
        if os.path.isfile(existing_engine_config_file):
            print("Migrating an existing config file from {!r} to {!r}".format(
                existing_engine_config_file, new_cfg_path))
            try:
                copyfile(existing_engine_config_file, new_cfg_path)
            except shutil.Error as e:
                print('Error: %s' % e)
        else:
            print("No config migration required.")
    except Exception as exc:
        print('Error: {}'.format(exc))

    print("Finished upgrade attempt.")

if __name__ == '__main__':
    attemptUpgrade()




