#!/bin/sh

echo "Installing gmq_demo app..."
set -x
mkdir -p /root/code/
cp gmq_demo.py /root/code//
set +x
echo "Installation complete."

