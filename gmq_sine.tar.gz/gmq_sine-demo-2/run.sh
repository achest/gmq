python -u ./gmq_demo.py py9c58520d8zd7vi 1234 n c61eec54e0939dc0b23777f63cb4fe95e691ee7c
